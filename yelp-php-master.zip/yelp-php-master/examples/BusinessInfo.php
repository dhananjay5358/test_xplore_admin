<?php
$start = microtime(true);
use TVW\Yelp;

require '../vendor/autoload.php';

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "xplore_29";

$conn = new mysqli($servername, $username, $password, $dbname);

$apiToken = 'A7F4RNSZ2wTYSwJ3xmpa8RYzTmw015wl_aPEa5cz3hYGoSvA5bLuP6ruxLpkyDLZS2Y27jNo0nJAz2vulnS-DLaXaSuoY54lnY76Dz-HrqzgVTD_QQZ6YHiyUeV1WXYx';

$yelpFusion = new Yelp($apiToken);
$in_str = '';
$update_str='';
$query = "SELECT SrNumber, Detail FROM Place_detail";
$result = $conn->query($query);
$sql = "UPDATE Place_detail SET ";

if ($result->num_rows > 0) {
    // output data of each row
   
    while($row = $result->fetch_assoc()) {
        $detail=json_decode($row['Detail'],true);
        
        if(isset($detail['businessId'])){
            if($detail['businessId']==""){
                echo "Business Id is empty";
            }
            else{
                 print_r($row['SrNumber']);
                 
                $businessesInfo = $yelpFusion->getDetails("details", $detail['businessId']);
                
                if(isset($businessesInfo->hours[0]))
                {

                        $open_hrs=$businessesInfo->hours[0]->open;

                        $isClosed=var_dump($businessesInfo->is_closed);
                        $is_Close_=$isClosed ? 'true' : 'false';
                
                        $hoursDay = '';
                        foreach ($open_hrs as $value) 
                        {
                            if($value->day==0){
                              $day="Monday";
                            }else if($value->day==1){
                              $day="Tuesday";
                            }else if($value->day==2){
                              $day="Wednesday";
                            }else if($value->day==3){
                              $day="Thursday";
                            }else if($value->day==4){
                              $day="Friday";
                            }else if($value->day==5){
                              $day="Saturday";
                            }else{
                              $day="Sunday";
                            }

                            if(!empty($hoursDay))
                            {
                                $hoursDay = $hoursDay.",".$day.'_'.$value->start.'_'.$value->end;    
                            }
                            else
                            {
                                $hoursDay = $day.'_'.$value->start.'_'.$value->end;       
                            }
                            
                            
                            $detail_ = array();
                            $detail_['name'] = isset($detail['name']) ? str_replace("'", '"', $detail['name']) : "";
                            $detail_['address']  = isset($detail['address']) ? str_replace("'", '"', $detail['address']) : "";
                            $detail_['price'] = isset($detail['price']) ? str_replace("'", '"', $detail['price']) : "";
                            $detail_['date'] = isset($detail['date']) ? str_replace("'", '"', $detail['date']) : "";
                            $detail_['startTime']  =isset($detail['startTime']) ? str_replace("'", '"', $detail['startTime']) : "";
                            $detail_['endTime'] = isset($detail['endTime']) ? str_replace("'", '"', $detail['endTime']) : "";
                            $detail_['about'] = isset($detail['about']) ? str_replace("'", '"', $detail['about']) : "";
                            $detail_['Reviews']  = isset($detail['Reviews']) ? str_replace("'", '"', $detail['Reviews']) : "";
                            $detail_['type'] = isset($detail['type']) ? str_replace("'", '"', $detail['type']) : "";
                            $detail_['businessId'] = isset($detail['businessId']) ? str_replace("'", '"', $detail['businessId']) : "";
                            $detail_['rating'] = isset($detail['rating']) ? str_replace("'", '"', $detail['rating']) : "";
                            $detail_['Phone'] = isset($detail['Phone']) ? str_replace("'", '"', $detail['Phone']) : "";
                            $detail_['Like'] = isset($detail['Like']) ? str_replace("'", '"', $detail['Like']) : "";
                            $detail_['Website']  = isset($detail['Website']) ? str_replace("'", '"', $detail['Website']) : "";
                            $detail_['Path'] = isset($detail['Path']) ? str_replace("'", '"', $detail['Path']) : "";
                            $detail_['profileimage'] = isset($detail['profileimage']) ? str_replace("'", '"', $detail['profileimage']) : "";
                            $detail_['isClosed'] = $is_Close_;
                            $detail_['hours'] = $hoursDay;

                            $detail_new = json_encode($detail_);
                           
                            $update_str .= "WHEN '".$row['SrNumber']."' THEN '".$detail_new."' ";
                            
                            if(empty($in_str))
                                $in_str .= "'".$row['SrNumber']."'";
                            else
                                $in_str .= ", '".$row['SrNumber']."'";
                        }

                    
                }
                }
                      

            }   
        
        }

    }else {
        echo "0 results";
    }
   
$sql .= "Detail = CASE SrNumber ";
$sql .= $update_str;
$sql .= "END";
$sql .= " WHERE SrNumber IN (".$in_str.");";
echo "<pre>";

print_r($sql);
exit();
//$qry_result = mysqli_query($conn, $sql);

$end = microtime(true) - $start;

echo "<pre>";
print_r($end);

$conn->close();

?>
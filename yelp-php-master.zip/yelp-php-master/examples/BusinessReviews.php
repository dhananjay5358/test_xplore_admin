<?php
$start = microtime(true);
use TVW\Yelp;

require '../vendor/autoload.php';

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test-explore";

$conn = new mysqli($servername, $username, $password, $dbname);

$apiToken = 'A7F4RNSZ2wTYSwJ3xmpa8RYzTmw015wl_aPEa5cz3hYGoSvA5bLuP6ruxLpkyDLZS2Y27jNo0nJAz2vulnS-DLaXaSuoY54lnY76Dz-HrqzgVTD_QQZ6YHiyUeV1WXYx';

$yelpFusion = new Yelp($apiToken);

$in_str = '';
$update_str='';
$query = "SELECT SrNumber, Detail FROM Place_detail";
$result = $conn->query($query);

$sql = "UPDATE Place_detail SET ";

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
         $detail=json_decode($row['Detail'],true);
        echo "<pre>";
        if(isset($detail['businessId'])){
            if($detail['businessId']==""){
                echo "Business Id is empty";
            }
            else{
                $businessesReviews = $yelpFusion->getDetails("reviews", $detail['businessId']);
                $reviewsInfo = '';
                foreach ($businessesReviews->reviews as $value) {
                   
                    if(!empty($reviewsInfo))
                    {
                        $reviewsInfo = $reviewsInfo."/".$value->text;    
                    }
                    else
                    {
                        $reviewsInfo = $value->text;       
                    }
                    
                    $text = str_replace("'", '', $reviewsInfo);

                }
                $update_str .= "WHEN '".$row['SrNumber']."' THEN '".$text."' ";
                    
                    if(empty($in_str))
                        $in_str .= "'".$row['SrNumber']."'";
                    else
                        $in_str .= ", '".$row['SrNumber']."'";
                    }

            }   
        }
        
    }
    else {
        echo "0 results";
    }


$sql .= "Reviews = CASE SrNumber ";
$sql .= $update_str;
$sql .= "END";
$sql .= " WHERE SrNumber IN (".$in_str.");";

//$qry_result = mysqli_query($conn, $sql);

$end = microtime(true) - $start;

print_r($end);
$conn->close();

?>
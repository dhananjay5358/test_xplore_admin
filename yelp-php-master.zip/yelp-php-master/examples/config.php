<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "xplore_29";

 	$conn = new mysqli($servername, $username, $password, $dbname);
?>
<?php
/**
 * This is an example script to demonstrate the methods in the TVW\Yelp Class.
 *
 * Uncomment the method you'd like to see a demonstration of and a var_dump
 * will be performed on the information returned.
 */
$start = microtime(true);
use TVW\Yelp;

require '../vendor/autoload.php';

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "xplore_29";

$conn = new mysqli($servername, $username, $password, $dbname);

/**
 * You must specify a Yelp Fusion API token for this demo
 * see: https://www.yelp.com/developers.
 */
$apiToken = 'A7F4RNSZ2wTYSwJ3xmpa8RYzTmw015wl_aPEa5cz3hYGoSvA5bLuP6ruxLpkyDLZS2Y27jNo0nJAz2vulnS-DLaXaSuoY54lnY76Dz-HrqzgVTD_QQZ6YHiyUeV1WXYx';

// create instance of Yelp-PHP class
$yelpFusion = new Yelp($apiToken);


$query = "SELECT SrNumber,Venueid,Detail FROM Place_detail limit 400";
$result = $conn->query($query);
$update_str='';
$in_str='';
$sql = "UPDATE Place_detail SET ";

if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {
        $detail=json_decode($row['Detail'],true);
        if(isset($detail['Phone'])){
            if(empty($detail['Phone']) || ($detail['Phone']=="undefined") ){
              //  echo "Phone number is empty or undefined";
            }
            else{
                echo "<pre>";
                print_r($row['SrNumber']);
                if (strpos($detail['Phone'], '+1') !== false) {
                    $phoneCode=$detail['Phone'];
                }
                else{
                   $phoneCode='+1'.$detail['Phone'];
                }

  
                $PhoneInfo = $yelpFusion->searchPhone($phoneCode);              
                
                $businessId = '';
                foreach ($PhoneInfo->businesses as $value) {
                                      
                    if(!empty($businessId))
                    {
                        $businessId = $businessId.",".$value->id;    
                    }
                    else
                    {
                        $businessId = $value->id;       
                    }


                    if(!empty($value->price)){
                        $price=$value->price;
                    }else{
                        $price=$detail['price'];
                    }

                    $detail_ = array();
                    $detail_['name'] = isset($detail['name']) ? str_replace("'", '"', $detail['name']) : "";
                    $detail_['address']  = isset($detail['address']) ? str_replace("'", '"', $detail['address']) : "";
                    $detail_['price'] = $price;
                    $detail_['date'] = isset($detail['date']) ? str_replace("'", '"', $detail['date']) : "";
                    $detail_['startTime']  =isset($detail['startTime']) ? str_replace("'", '"', $detail['startTime']) : "";
                    $detail_['endTime'] = isset($detail['endTime']) ? str_replace("'", '"', $detail['endTime']) : "";
                    $detail_['about'] = isset($detail['about']) ? str_replace("'", '"', $detail['about']) : "";
                    $detail_['Reviews']  = isset($detail['Reviews']) ? str_replace("'", '"', $detail['Reviews']) : "";
                    $detail_['type'] = isset($detail['type']) ? str_replace("'", '"', $detail['type']) : "";
                    $detail_['businessId'] = $businessId;
                    $detail_['rating'] = $value->rating;
                    $detail_['Phone'] = isset($detail['Phone']) ? str_replace("'", '"', $detail['Phone']) : "";
                    $detail_['Like'] = isset($detail['Like']) ? str_replace("'", '"', $detail['Like']) : "";
                    $detail_['Website']  = isset($detail['Website']) ? str_replace("'", '"', $detail['Website']) : "";
                    $detail_['Path'] =isset($detail['Path']) ? str_replace("'", '"', $detail['Path']) : "";
                    $detail_['profileimage'] = isset($detail['profileimage']) ? str_replace("'", '"', $detail['profileimage']) : "";
                    $detail_['isClosed'] = isset($detail['isClosed']) ? str_replace("'", '"', $detail['isClosed']) : "";
                    $detail_['hours'] = isset($detail['hours']) ? str_replace("'", '"', $detail['hours']) : "";
                   
                    $detail_new = json_encode($detail_);
                    
                    $update_str .= "WHEN '".$row['SrNumber']."' THEN '".$detail_new."' ";

                    if(empty($in_str))
                        $in_str .= "'".$row['SrNumber']."'";
                    else
                        $in_str .= ", '".$row['SrNumber']."'";
                    
                    }
                    
                }
                    

            }   
        
        }
    }else {
        echo "0 results";
    }

$sql .= "Detail = CASE SrNumber ";
$sql .= $update_str;
$sql .= "END";
$sql .= " WHERE SrNumber IN (".$in_str.");";

print_r($sql);

$qry_result = mysqli_query($conn, $sql);

$end = microtime(true) - $start;

echo "<pre>";
print_r($end);

$conn->close();


?>
<?php
class places_model extends CI_Model
{

	public function __construct()
	{
		$this->load->database();
	}

	function get_custom_places($wheres = array(),$total = false, $limit = 10, $offset = 0,$all = false)
	{
		if(!empty($wheres))
		{
			foreach($wheres as $key => $val)
			{
				$this->db->where($key , $val);
			}
		}

		if(!$total && !$all)
		{
			$this->db->limit($limit,$offset); 
		}
		
		$query = $this->db->get('custom_places');
		
		if($query->num_rows() > 0)
		{
			if($total)
			{
				$data = $query->num_rows();
			}
			else
			{
				$data = $query->result_array();
			}
			return $data;
		}
		return false;
	}

	function remove_custom_place($id)
	{
		$this->db->where('sr_no', $id);
		$this->db->delete('custom_places');
	}

	function edit_custom_place($id,$data)
	{
		$this->db->where('sr_no', $id);
		$this->db->update('custom_places', $data); 
	}

	function accept_custom_place($data)
	{
		$this->db->set($data);
	    $this->db->insert('Place_detail',$data);    
	    return $this->db->insert_id();    
	}

	function save_custom_place($data)
	{
		$this->db->set($data);
	    $this->db->insert('custom_places',$data);    
	    return $this->db->insert_id(); 
	}

	function save_custom_news($data)
	{
		$this->db->set($data);
	    $this->db->insert('custom_news',$data);    
	    return $this->db->insert_id(); 
	}

	function get_custom_news($wheres = array(),$total = false, $limit = 10, $offset = 0,$all = false)
	{
		if(!empty($wheres))
		{
			foreach($wheres as $key => $val)
			{
				$this->db->where($key , $val);
			}
		}

		if(!$total && !$all)
		{
			$this->db->limit($limit,$offset); 
		}
		
		$query = $this->db->get('custom_news');
		
		if($query->num_rows() > 0)
		{
			if($total)
			{
				$data = $query->num_rows();
			}
			else
			{
				$data = $query->result_array();
			}
			return $data;
		}
		return false;
	}

	function update_custom_news($data,$id)
	{
		$this->db->where('sr_no', $id);
		$this->db->update('custom_news', $data); 
	}

	function remove_custom_news($id)
	{
		$this->db->where('sr_no', $id);
		$this->db->delete('custom_news');
	}

	function get_news()
	{
		$query = $this->db->get('custom_news');
		
		if($query->num_rows() > 0)
		{
			$data = $query->result_array();
			return $data;
		}
		return false;
	}
	
}

?>
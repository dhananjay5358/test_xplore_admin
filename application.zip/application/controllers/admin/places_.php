<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class places_ extends CI_Controller {
	var $awsAccessKey = "AKIAJ2RVZ5W24XMUFG5A"; 
	var $awsSecretKey = "7GiP5Tidb/Qff0cLn41VnlHgKcJQ4kdUTFOIm4wz";
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();
		$this->load->model('admin/places_model');
		$this->load->model('site_model');
		$this->load->library('pagination');	
		$this->load->library('session');
		require_once(APPPATH.'libraries/S3.php');
	}

	public function index()
	{
		// if($this->session->userdata('identity'))
		// {
			$limit = 10;
			$offset = 0;
			if($total = $this->places_model->get_custom_places(array(),true))
			{
				$config['base_url'] = site_url('admin/Places/index/');
				$config['total_rows'] = $total;
				$config['per_page'] = $limit = 10;
				$config['uri_segment'] = 4;
				$config['num_links'] = 2;	
				
				$config['first_tag_open'] = '<li>';
				$config['first_tag_close'] = '</li>';
				$config['last_tag_open'] = '<li>';
				$config['last_tag_close'] = '</li>';
				$config['next_tag_open'] = '<li class="next">';
				$config['next_tag_close'] = '</li>';
				$config['prev_tag_open'] = '<li class="previous">';
				$config['prev_tag_close'] = '</li>';
				$config['cur_tag_open'] = '<li class="active">';
				$config['cur_tag_close'] = '</li>';
				$config['num_tag_open'] = '<li>';
				$config['num_tag_close'] = '</li>';
				// Initialize
				$this->pagination->initialize($config);
				$pages = $this->pagination->create_links();	
				$offset = $this->uri->segment(4) ? $this->uri->segment(4) : 0;
				$data['pages'] = $pages;
				$data['index'] = $offset;	
			}
				
			if(!($place_list = $this->places_model->get_custom_places(array(),false,$limit,$offset)))
			{
				$place_list['0'] = "no-data";	
			}
			$data['admin_header']=$this->load->view('admin/admin_header','',true);
			$data['galleries']= $place_list;
			$this->load->view('admin/Places_list',$data);
		// }
		// else
		// {
		// 	header('Location:'.site_url('admin/login/index') );
		// }
	}
	
	public function add_or_remove_custom_place()
	{
		if($_POST['status'] === 'remove')
		{
			$ids = $_POST['id'];
			$this->places_model->remove_custom_place($ids);		
		}
		exit;
	}

	public function edit_Place()
	{
		if($_POST['id'] != '')
		{
			$id = $_POST['id'];
			$place_name = $_POST['place_name'];
			$address = $_POST['address'];
			$description = $_POST['description'];
			$category = $_POST['category'];
			$longitude = $_POST['longitude'];
			$latitude = $_POST['latitude'];
			$web = $_POST['web'];
			$phone = $_POST['phone'];
			$Image = $_POST['Image'];
				
			$data = array( 'place_name' => $place_name,'address' => $address,'description' => $description,'category' => $category,'longitude' => $longitude,'latitude' => $latitude,'web' => $web,'phone' => $phone,'Image' => $Image );

			$this->places_model->edit_custom_place($id,$data);		
		}
		echo $_POST['id'];
	}

	public function accept_Place()
	{
		if($_POST['id'] != '')
		{
			$id = $_POST['id'];
			$Image = $_POST['Image'];

			$LatLng='{ "H":'.$_POST['latitude'].', "L":'.$_POST['longitude'].'}';

			$e = array();
			$e['name'] = $_POST['place_name'];
		    $e['address']  = $_POST['address'];
		    $e['price'] = "";
		    $e['date'] = "";
		    $e['startTime']  = "";
		    $e['endTime'] = "";
		    $e['about'] = base64_encode($_POST['description']);
		    $e['Reviews']  = "";
		    $e['type'] = $_POST['category'];
		    $e['Info_1'] = "";
		    $e['Info_2'] = "";
		    $e['Info_3'] =  "";
		    $e['Phone'] = $_POST['phone'];
		    $e['Website'] = $_POST['web'];
		    $e['Path'] = '';
		    $e['profileimage'] = $Image;

		    $placeId = random_string('alnum',20);
	 		$venueId = $placeId;

  			$detail = json_encode($e);
      		if(($sitelist = $this->site_model->addEventsPlaces($e['type'],$detail,$LatLng,$LatLng,$placeId,$venueId,"false")))
	  		{
				$this->places_model->remove_custom_place($id);	
	  		}	
	  		echo $venueId;	
		}
	}

	public function experiance()
	{
			$limit = 10;
			$offset = 0;
			if($total = $this->places_model->get_custom_places(array(),true))
			{
				$config['base_url'] = site_url('admin/Places/index/');
				$config['total_rows'] = $total;
				$config['per_page'] = $limit = 10;
				$config['uri_segment'] = 4;
				$config['num_links'] = 2;	
				
				$config['first_tag_open'] = '<li>';
				$config['first_tag_close'] = '</li>';
				$config['last_tag_open'] = '<li>';
				$config['last_tag_close'] = '</li>';
				$config['next_tag_open'] = '<li class="next">';
				$config['next_tag_close'] = '</li>';
				$config['prev_tag_open'] = '<li class="previous">';
				$config['prev_tag_close'] = '</li>';
				$config['cur_tag_open'] = '<li class="active">';
				$config['cur_tag_close'] = '</li>';
				$config['num_tag_open'] = '<li>';
				$config['num_tag_close'] = '</li>';
				// Initialize
				$this->pagination->initialize($config);
				$pages = $this->pagination->create_links();	
				$offset = $this->uri->segment(4) ? $this->uri->segment(4) : 0;
				$data['pages'] = $pages;
				$data['index'] = $offset;	
			}
				
			if(!($place_list = $this->places_model->get_custom_places(array(),false,$limit,$offset)))
			{
				$place_list['0'] = "no-data";	
			}
			$data['admin_header']=$this->load->view('admin/admin_header','',true);
			$data['galleries']= $place_list;
			$this->load->view('admin/Custom_experiances',$data);
	}

	public function News()
	{
		$limit = 10;
		$offset = 0;
		if($total = $this->places_model->get_custom_news(array(),true))
		{
			$config['base_url'] = site_url('admin/Places/index/');
			$config['total_rows'] = $total;
			$config['per_page'] = $limit = 10;
			$config['uri_segment'] = 4;
			$config['num_links'] = 2;	
			
			$config['first_tag_open'] = '<li>';
			$config['first_tag_close'] = '</li>';
			$config['last_tag_open'] = '<li>';
			$config['last_tag_close'] = '</li>';
			$config['next_tag_open'] = '<li class="next">';
			$config['next_tag_close'] = '</li>';
			$config['prev_tag_open'] = '<li class="previous">';
			$config['prev_tag_close'] = '</li>';
			$config['cur_tag_open'] = '<li class="active">';
			$config['cur_tag_close'] = '</li>';
			$config['num_tag_open'] = '<li>';
			$config['num_tag_close'] = '</li>';
			
			$this->pagination->initialize($config);
			$pages = $this->pagination->create_links();	
			$offset = $this->uri->segment(4) ? $this->uri->segment(4) : 0;
			$data['pages'] = $pages;
			$data['index'] = $offset;	
		}
			
		if(!($news_list = $this->places_model->get_custom_news(array(),false,$limit,$offset)))
		{
			$news_list['0'] = "no-data";	
		}

		$data['experiances']= $news_list;
		$data['admin_header']=$this->load->view('admin/admin_header','',true);
		$this->load->view('admin/Cust_News',$data);
	}

	public function save_news()
	{
		$Title_  	= 	$_POST['Title_'];
		$Excerpt_  	= 	$_POST['Excerpt_'];
		$Link_  	= 	$_POST['Link_'];
		$date_  	= 	$_POST['date_'];

		if(isset($_FILES['Image_']['name']) && (!empty($_FILES['Image_']['name'])))
		{
			$size = $_FILES['Image_']['size'];

	        if ($size < 1000000)
	        {
				$s3 = new S3($this->awsAccessKey, $this->awsSecretKey);

				$fileName = $_FILES['Image_']['name'];
		        $fileTempName = $_FILES['Image_']['tmp_name'];             
		        $newfilename = round(microtime(true)) . '.jpeg';

		        if($s3->putObjectFile($fileTempName, "retail-safari", $newfilename, S3::ACL_PUBLIC_READ))
	        	{
	        		$Image = $newfilename;
	        		
	        		$data = array();
	        		$data['Title'] = $Title_;
	        		$data['Excerpt'] = $Excerpt_;
	        		$data['Link'] = $Link_; 
	        		$data['Date'] = $date_;
	        		$data['Image'] = $Image;

	        		$save_News = $this->places_model->save_custom_news($data);

	        		echo $save_News;
	        	}
	        	else
	        	{
	        		echo 'error';
	        	}
	        }
	        else
	        {
	        	echo "size_issue";
	        }
		}
		else
		{
			echo "empty";
		}

		redirect('/admin/places_/News');
	}


	public function edit_news()
	{
		if($_POST['id'] != '')
		{
			$id 		= 	$_POST['id'];
			$Title_  	= 	$_POST['Title_'];
			$Excerpt_  	= 	$_POST['Excerpt_'];
			$Link_  	= 	$_POST['Link_'];
			$date_  	= 	$_POST['date_'];
			$Image 		= 	$_POST['id_image'];	

			if(isset($_FILES['Image_']['name']) && (!empty($_FILES['Image_']['name'])))
			{
				$size = $_FILES['Image_']['size'];

		        if ($size < 1000000)
		        {
					$s3 = new S3($this->awsAccessKey, $this->awsSecretKey);

					$fileName = $_FILES['Image_']['name'];
			        $fileTempName = $_FILES['Image_']['tmp_name'];             
			        $newfilename = round(microtime(true)) . '.jpeg';

			        if($s3->putObjectFile($fileTempName, "retail-safari", $newfilename, S3::ACL_PUBLIC_READ))
		        	{
		        		$Image = $newfilename;
		        		
		        		$data = array();
		        		$data['Title'] = $Title_;
		        		$data['Excerpt'] = $Excerpt_;
		        		$data['Link'] = $Link_; 
		        		$data['Date'] = $date_;
		        		$data['Image'] = $Image;

		        		$save_News = $this->places_model->update_custom_news($data,$id);

		        		echo $save_News;
		        	}
		        	else
		        	{
		        		echo 'error';
		        	}
		        }
		        else
		        {
		        	echo 'size issue';
		        }
			}
			else
			{
				$data = array();
        		$data['Title'] = $Title_;
        		$data['Excerpt'] = $Excerpt_;
        		$data['Link'] = $Link_; 
        		$data['Date'] = $date_;
        		$data['Image'] = $Image;

        		$save_News = $this->places_model->update_custom_news($data,$id);

        		echo $save_News;
			}	
		}
		echo $_POST['id'];
		redirect('/admin/places_/News');
	}

	public function add_or_remove_custom_news()
	{
		if($_POST['status'] === 'remove')
		{
			$ids = $_POST['id'];
			$this->places_model->remove_custom_news($ids);		
		}
		exit;
	}

	function get_news()
	{
		$data = $this->places_model->get_news();
		echo $_GET['callback'] .'('. json_encode($data) . ')';
		exit;	
	}

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
<!-- left menu starts -->
			<div class="span2 main-menu-span">
				<div class="well nav-collapse sidebar-nav">
					<ul class="nav nav-tabs nav-stacked main-menu">
					
					  <li><a class="ajax-link" href="<?php echo site_url('admin/login/home');?>"><i class="icon-home"></i><span class="hidden-tablet"> Dashboard</span></a></li>
					  <li><a class="ajax-link" href="<?php echo site_url('admin/interests/index');?>"><i class="icon-eye-open"></i>
					      <span class="hidden-tablet"> Historical Interest</span></a>
					  </li>
					  <li><a class="ajax-link" href="<?php echo site_url('admin/site/index');?>"><i class="icon-edit"></i>
					       <span class="hidden-tablet"> Historical Sites</span></a>
					  </li>
					  <li><a class="ajax-link" href="<?php echo site_url('admin/gallery/index');?>"><i class="icon-picture"></i>
					      <span class="hidden-tablet">  Image Gallery </span></a>
					  </li>
					 <li><a class="ajax-link" href="<?php echo site_url('admin/media/index');?>"><i class="icon-list-alt"></i>
					      <span class="hidden-tablet"> Media</span></a>
					  </li>
					  <li><a class="ajax-link" href="<?php echo site_url('admin/welcome_message/index');?>"><i class="icon-font"></i>
					      <span class="hidden-tablet"> Welcome Messages</span></a>
					  </li>
					  <li><a class="ajax-link" href="<?php echo site_url('admin/help/index');?>"><i class="icon-font"></i>
					      <span class="hidden-tablet"> Help</span></a>
					  </li>
					   <li><a class="ajax-link" href="<?php echo site_url('site/SharedEvents');?>"><i class="icon-font"></i>
					      <span class="hidden-tablet"> Places</span></a>
					  </li>
					  <li><a class="ajax-link" href="<?php echo site_url('site/SharedPlaces');?>"><i class="icon-font"></i>
					      <span class="hidden-tablet"> Events</span></a>
					  </li>
					  <li><a class="ajax-link" href="<?php echo site_url('site/Deals');?>"><i class="icon-font"></i>
					      <span class="hidden-tablet"> Deals</span></a>
					  </li>
					  <li><a class="ajax-link" href="<?php echo site_url('admin/places_/index');?>"><i class="icon-font"></i>
					      <span class="hidden-tablet"> Custom Places</span></a>
					  </li>
			        </ul>
					<!--<label id="for-is-ajax" class="hidden-tablet" for="is-ajax"><input id="is-ajax" type="checkbox"> Ajax on menu</label>-->
				</div><!--/.well -->
			</div><!--/span-->
			<!-- left menu ends -->
			
			<noscript>
				<div class="alert alert-block span10">
					<h4 class="alert-heading">Warning!</h4>
					<p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
				</div>
			</noscript>
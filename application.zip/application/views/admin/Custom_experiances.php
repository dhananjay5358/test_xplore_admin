<html>
	<head>
		<style>
			.jqimessage input{
				width: 87%;
			}
		</style>
		<title>Custom Places List</title>
		<script type="text/javascript">
			
			function prompt_delete_gallery(id)
			{
				var show_delete_media_box=[{
							title:"Delete Image Gallery",
							html: "<strong>are you really want to delete this Gallery ?</strong>",
							buttons:{"Delete" : true , "Cancel" : false},
							submit: function(e,v,m,f){
								if(v==true)
								{									
									conformed_delete_gallery(id);									
								}
							
							}
						}];
				$.prompt(show_delete_media_box);
			}
			
			function conformed_delete_gallery(id)
			{
				$.ajax({
							url: '<?php echo site_url('admin/places_/add_or_remove_custom_place');?>',		
							type: 'POST',
							data: {
									'status' : 'remove' ,
									'id': id
								  },
							success: function(resp) {
								//alert(resp);
								window.location.reload();						
							}
						});
			
			}

			function prompt_accept_gallery(id)
			{
				var data = $(id).closest('tr');

				var html = "<br/><label>Place name</label><input type='text' value='"+data.find('.place_name').html()+"' id='place_name_'/><br/><label>Address</label><input type='text' value='"+data.find('.address').html()+"' id='address_'/><br/><label>Description</label><input type='text' value='"+data.find('.description').html()+"' id='description_'/><br/><label>Category</label><input type='text' value='"+data.find('.category').html()+"' id='category_'/></br><label>Longitude</label><input type='text' value='"+data.find('.longitude').html()+"' id='longitude_'/><br/><label>Latitude</label><input type='text' value='"+data.find('.latitude').html()+"' id='latitude_'/><br/><label>Website</label><input type='text' value='"+data.find('.web').html()+"' id='web_'/><br/><label>Phone</label><input type='text' value='"+data.find('.phone').html()+"' id='phone_'/><br/><label>Image</label><input type='text' value='"+data.find('.Image').html()+"'  id='Image_'/>";
				var show_delete_media_box=[{
							title:"Accept place",
							html: html,
							buttons:{"accept" : true , "Cancel" : false},
							submit: function(e,v,m,f){
								if(v==true)
								{									
									accept_gallery(id);									
								}
							
							}
						}];
				$.prompt(show_delete_media_box);
			}

			function prompt_edit_gallery(id)
			{
				var data = $(id).closest('tr');
				// alert(data.find('.place_name').html());
				// data.find('.address').html();
				// data.find('.longitude').html();
				// data.find('.latitude').html();
				// data.find('.web').html();
				// data.find('.phone').html();
				// data.find('.Image').html();

				var html = "<br/><label>Place name</label><input type='text' value='"+data.find('.place_name').html()+"' id='place_name'/><br/><label>Address</label><input type='text' value='"+data.find('.address').html()+"' id='address'/><br/><label>Description</label><input type='text' value='"+data.find('.description').html()+"' id='description'/><br/><label>Category</label><input type='text' value='"+data.find('.category').html()+"' id='category'/></br><label>Longitude</label><input type='text' value='"+data.find('.longitude').html()+"' id='longitude'/><br/><label>Latitude</label><input type='text' value='"+data.find('.latitude').html()+"' id='latitude'/><br/><label>Website</label><input type='text' value='"+data.find('.web').html()+"' id='web'/><br/><label>Phone</label><input type='text' value='"+data.find('.phone').html()+"' id='phone'/><br/><label>Image</label><input type='text' value='"+data.find('.Image').html()+"'  id='Image'/>";
				var show_delete_media_box=[{
							title:"Edit place",
							html: html,
							buttons:{"Edit" : true , "Cancel" : false},
							submit: function(e,v,m,f){
								if(v==true)
								{									
									edit_gallery(id);									
								}
							
							}
						}];
				$.prompt(show_delete_media_box);
			}

			function accept_gallery(id)
			{
				var place_name = $('#place_name_').val();
				var address = $('#address_').val();
				var longitude = $('#longitude_').val();
				var latitude = $('#latitude_').val();
				var web = $('#web_').val();
				var phone = $('#phone_').val();
				var Image = $('#Image_').val();
				var description = $('#description_').val();
				var category = $('#category_').val();
				
				$.ajax({
						url: '<?php echo site_url('admin/places_/accept_Place');?>',		
						type: 'POST',
						data: {
								'id' : $(id).attr('id'),
								'place_name' : place_name ,
								'address': address,
								'longitude': longitude,
								'latitude': latitude,
								'web': web,
								'phone': phone,
								'Image': Image,
								'description' : description,
								'category' : category
							  },
						success: function(resp) {
							//thiss.parentNode.previousSibling.innerHTML = interest;
							//window.location.reload();
							console.log(resp);	
						}
				});
			}

			function edit_gallery(id)
			{
				var place_name = $('#place_name').val();
				var address = $('#address').val();
				var longitude = $('#longitude').val();
				var latitude = $('#latitude').val();
				var web = $('#web').val();
				var phone = $('#phone').val();
				var Image = $('#Image').val();
				var description = $('#description').val();
				var category = $('#category').val();
				
				$.ajax({
						url: '<?php echo site_url('admin/places_/edit_Place');?>',		
						type: 'POST',
						data: {
								'id' : $(id).attr('id'),
								'place_name' : place_name ,
								'address': address,
								'longitude': longitude,
								'latitude': latitude,
								'web': web,
								'phone': phone,
								'Image': Image,
								'description' : description,
								'category' : category
							  },
						success: function(resp) {
							//thiss.parentNode.previousSibling.innerHTML = interest;
							window.location.reload();
							//console.log(resp);	
						}
				});
			}

			function edit_gallery(id)
			{
				var place_name = $('#place_name').val();
				var address = $('#address').val();
				var longitude = $('#longitude').val();
				var latitude = $('#latitude').val();
				var web = $('#web').val();
				var phone = $('#phone').val();
				var Image = $('#Image').val();
				var description = $('#description').val();
				var category = $('#category').val();
				
				$.ajax({
						url: '<?php echo site_url('admin/places_/edit_Place');?>',		
						type: 'POST',
						data: {
								'id' : $(id).attr('id'),
								'place_name' : place_name ,
								'address': address,
								'longitude': longitude,
								'latitude': latitude,
								'web': web,
								'phone': phone,
								'Image': Image,
								'description' : description,
								'category' : category
							  },
						success: function(resp) {
							//thiss.parentNode.previousSibling.innerHTML = interest;
							window.location.reload();
							//console.log(resp);	
						}
				});
			}

			function Create_experiance()
			{
				var html = "<br/><label>Tour name</label><input type='text' value='' id='Tour_name'/><br/><label>Description</label><input type='text' value='' id='description'/><br/><label>Description</label><input type='text' value='' id='description'/><br/><label>Category</label><input type='text' value='' id='category'/></br><label>Longitude</label><input type='text' value='' id='longitude'/><br/><label>Latitude</label><input type='text' value='' id='latitude'/><br/><label>Website</label><input type='text' value='' id='web'/><br/><label>Phone</label><input type='text' value='' id='phone'/><br/><label>Image</label><input type='text' value=''  id='Image'/>";
				var show_delete_media_box=[{
							title:"Edit place",
							html: html,
							buttons:{"Edit" : true , "Cancel" : false},
							submit: function(e,v,m,f){
								if(v==true)
								{									
									edit_gallery(id);									
								}
							
							}
						}];
				$.prompt(show_delete_media_box);
			}
						
		</script>
	</head>
	<body>
		<?php echo $admin_header;?>
		<div class="container-fluid">
		  <div class="row-fluid">
		   
		   <?php include 'left-sidebar.php'; ?> 
		   
			<div id="content" class="span10">
				<div class="box span12">
					<div class="box-header well" data-original-title>
						<h2><i class="icon-user"></i> Custom Places List</h2>
						<div class="box-icon">
							<!--<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>-->
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						
						<table class="table table-striped table-bordered bootstrap-datatable datatable">
							<thead>
								<tr>
									<th>Index</th>
									<th>Tour_name</th>
									<th>tour_description</th>
									<th>Tags</th>
									<th>Public_private_group</th>
									<th>Places</th>
									<th><a class="btn btn-info" id="" onClick="" ><i class="icon-plus icon-white"></i>Create</a></th>
								</tr>
							</thead>
							<tbody id='galleryList'>
								<?php 	
								//if($experiances['0'] != "no-data") 
								if($galleries['0'] != "no-data") 
								{
									$i = (isset($index) ? $index : 0);
									// foreach($experiances as $gallery)
									foreach($galleries as $gallery)
									{ 
										$i++;
										?>
										<tr id="gallery_">
											<td><?php echo $i;?></td>
											<td class="Tour_name" >Tour_name</td>
											<td class="description" >tour_description</td>
											<td class="category" >Tags</td>
											<td class="web" >Public_private_group</td>
											<td class="web" >Places</td>
											<td ><a class="btn btn-info" id="<?php echo $gallery['sr_no'];?>" onClick="prompt_edit_gallery(this); return false;" ><i class="icon-edit icon-white"></i>Edit</a>	<a class="btn btn-danger"  href="#" onClick="prompt_delete_gallery(this.id); return false;" id="<?php echo $gallery['sr_no'];?>">	<i class="icon-trash icon-white"></i>Delete</a>   <a class="btn btn-info"  href="#" onClick="prompt_accept_gallery(this); return false;" id="<?php echo $gallery['sr_no'];?>">	<i class="icon-heart icon-white"></i>Accept</a></td>								
										</tr>
									<?php
									}
								} 
								?>
							</tbody>	
						</table>
						</div>
				  	</div>
				
		<ul id="pagination-digg"><?php if(isset($pages)) echo $pages;?></ul>	
	   </div>
    </div>
	
	<?php include 'admin-footer.php'; ?>
	
   </div>		
	</body>
</html>

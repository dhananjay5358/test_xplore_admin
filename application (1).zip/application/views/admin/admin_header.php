<!--dacss files of responsive admin panel starts here-->
		<link href="<?php echo base_url('css/bootstrap-responsive.css');?>" rel="stylesheet">
		<link href="<?php echo base_url('css/bootstrap-cerulean.css');?>" rel="stylesheet">
		<link href="<?php echo base_url('css/charisma-app.css');?>" rel="stylesheet">
		<link href="<?php echo base_url('css/jquery-ui-1.8.21.custom.css');?>" rel="stylesheet">
		<link href='<?php echo base_url('css/fullcalendar.css');?>' rel='stylesheet'>
		<link href='<?php echo base_url('css/fullcalendar.print.css');?>' rel='stylesheet'  media='print'>
		<link href='<?php echo base_url('css/chosen.css');?>' rel='stylesheet'>
		<link href='<?php echo base_url('css/uniform.default.css');?>' rel='stylesheet'>
		<link href='<?php echo base_url('css/colorbox.css');?>' rel='stylesheet'>
		<link href='<?php echo base_url('css/jquery.cleditor.css');?>' rel='stylesheet'>
		<link href='<?php echo base_url('css/jquery.noty.css');?>' rel='stylesheet'>
		<link href='<?php echo base_url('css/noty_theme_default.css');?>' rel='stylesheet'>
		<link href='<?php echo base_url('css/elfinder.min.css');?>' rel='stylesheet'>
		<link href='<?php echo base_url('css/elfinder.theme.css');?>' rel='stylesheet'>
		<link href='<?php echo base_url('css/jquery.iphone.toggle.css');?>' rel='stylesheet'>
		<link href='<?php echo base_url('css/opa-icons.css');?>' rel='stylesheet'>
		<link href='<?php echo base_url('css/uploadify.css');?>' rel='stylesheet'>
		<link href='<?php echo base_url('css/font-awesome.min.css');?>' rel='stylesheet'>
		<link rel="stylesheet" href="<?php echo base_url("kendo/styles/kendo.default.min.css");?>">
        <link rel="stylesheet" href="<?php echo base_url("kendo/styles/kendo.common.min.css");?>">
        <link rel="stylesheet" href="<?php echo base_url("kendo/styles/kendo.default.mobile.min.css");?>">

	<!--css files of responsive admin panel ends here-->
	
	<link href="<?php echo base_url('css/admin.css');?>" media="screen" rel="stylesheet" type="text/css"/>
	
	<!--js files of responsive admin panel starts here-->
		<script src="<?php echo base_url("js/jquery-1.12.0.min.js"); ?>"></script> 
	    <script src="<?php //echo base_url('js/jquery-1.7.2.min.js');?>"></script>
	   	<!-- jQuery UI -->
		                <script src="<?php echo base_url('js/jquery-ui.js');?>"></script>

		<script src="<?php //echo base_url('js/jquery-ui-1.8.21.custom.min.js');?>"></script>
		<!-- transition / effect library -->
		<script src="<?php echo base_url('js/bootstrap-transition.js');?>"></script>
		<!-- alert enhancer library -->
		<script src="<?php echo base_url('js/bootstrap-alert.js');?>"></script>
		<!-- modal / dialog library -->
		<script src="<?php echo base_url('js/bootstrap-modal.js');?>"></script>
		<!-- custom dropdown library -->
		<script src="<?php echo base_url('js/bootstrap-dropdown.js');?>"></script>
		<!-- scrolspy library -->
		<script src="<?php echo base_url('js/bootstrap-scrollspy.js');?>"></script>
		<!-- library for creating tabs -->
		<script src="<?php echo base_url('js/bootstrap-tab.js');?>"></script>
		<!-- library for advanced tooltip -->
		<script src="<?php echo base_url('js/bootstrap-tooltip.js');?>"></script>
		<!-- popover effect library -->
		<script src="<?php echo base_url('js/bootstrap-popover.js');?>"></script>
		<!-- button enhancer library -->
		<script src="<?php echo base_url('js/bootstrap-button.js');?>"></script>
		<!-- accordion library (optional, not used in demo) -->
		<script src="<?php echo base_url('js/bootstrap-collapse.js');?>"></script>
		<!-- carousel slideshow library (optional, not used in demo) -->
		<script src="<?php echo base_url('js/bootstrap-carousel.js');?>"></script>
		<!-- autocomplete library -->
		<script src="<?php echo base_url('js/bootstrap-typeahead.js');?>"></script>
		<!-- tour library -->
		<script src="<?php echo base_url('js/bootstrap-tour.js');?>"></script>
		<!-- library for cookie management -->
		<script src="<?php echo base_url('js/jquery.cookie.js');?>"></script>
		<!-- calander plugin -->
		<script src='<?php echo base_url('js/fullcalendar.min.js');?>'></script>
		<!-- data table plugin -->
		<script src='<?php //echo base_url('js/jquery.dataTables.min.js');?>'></script>
	
		<!-- chart libraries start -->
		<script src="<?php echo base_url('js/excanvas.js');?>"></script>
		<script src="<?php echo base_url('js/jquery.flot.min.js');?>"></script>
		<script src="<?php echo base_url('js/jquery.flot.pie.min.js');?>"></script>
		<script src="<?php echo base_url('js/jquery.flot.stack.js');?>"></script>
		<script src="<?php echo base_url('js/jquery.flot.resize.min.js');?>"></script>
		<!-- chart libraries end -->

	
		<!-- select or dropdown enhancer -->
		<script src="<?php echo base_url('js/jquery.chosen.min.js');?>"></script>
		<!-- checkbox, radio, and file input styler -->
		<script src="<?php echo base_url('js/jquery.uniform.min.js');?>"></script>
		<!-- plugin for gallery image view -->
		<script src="<?php echo base_url('js/jquery.colorbox.min.js');?>"></script>
		<!-- rich text editor library -->
		<script src="<?php echo base_url('js/jquery.cleditor.min.js');?>"></script>
		<!-- notification plugin -->
		<script src="<?php echo base_url('js/jquery.noty.js');?>"></script>
		<!-- file manager library -->
		<script src="<?php echo base_url('js/jquery.elfinder.min.js');?>"></script>
		<!-- star rating plugin -->
		<script src="<?php echo base_url('js/jquery.raty.min.js');?>"></script>
		<!-- for iOS style toggle switch -->
		<script src="<?php echo base_url('js/jquery.iphone.toggle.js');?>"></script>
		<!-- autogrowing textarea plugin -->
		<script src="<?php echo base_url('js/jquery.autogrow-textarea.js');?>"></script>
		<!-- multiple file upload plugin -->
		<script src="<?php echo base_url('js/jquery.uploadify-3.1.min.js');?>"></script>
		<!-- history.js for cross-browser state change on ajax -->
		<script src="<?php echo base_url('js/jquery.history.js');?>"></script>
		<!-- application script for Charisma demo -->
		<script src="<?php //echo base_url('js/charisma.js');?>"></script>
		
		<script src="<?php echo base_url("kendo/js/kendo.web.min.js"); ?>"></script>  
	    <script src="<?php echo base_url("kendo/js/kendo.all.min.js"); ?>"></script>  
	<!--js files of responsive admin panel ends here-->


        
		<script src="<?php echo base_url('js/jquery-impromptu.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('js/ajaxfileupload.js');?>"></script>
       <!-- <script src="<?php echo base_url('js/jpicker-1.1.6.js');?>"></script>-->
		
		<link href="<?php echo base_url('css/jquery-impromptu.css');?>" media="screen" rel="stylesheet" type="text/css"/>
		<link href="<?php echo base_url('css/pagination-style.css');?>" media="screen" rel="stylesheet" type="text/css"/>
		<!--<link href="<?php echo base_url('css/jPicker-1.1.6.css');?>" media="screen" rel="stylesheet" type="text/css"/>-->
        <link href="<?php echo base_url('css/admin.css');?>" media="screen" rel="stylesheet" type="text/css"/>
               



    <!-- topbar starts -->
	<div class="logo">	<img alt="Charisma Logo" src="<?php echo base_url(); ?>images/logo.png" /></div>
	<div class="navbar">
		<div class="navbar-inner">
			<div class="container-fluid">
				<a class="btn btn-navbar" data-toggle="collapse" data-target=".top-nav.nav-collapse,.sidebar-nav.nav-collapse">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>
				<a class="brand" href="" style="width:60px;"> <img alt="Charisma Logo" src="<?php echo base_url(); ?>img/logo20.png" /> <span></span></a>

				<ul class="nav navbar-nav ">
                      <li><a class="ajax-link" href="<?php echo site_url('admin/login/home');?>"><i class="icon-home"></i><span class="hidden-tablet"> Dashboard</span></a></li>
                      <li><a class="ajax-link" href="<?php echo site_url('site/viewPlaces');?>"><i class="icon-font"></i><span class="hidden-tablet"> View places</span></a></li>
                      <li><a class="ajax-link" href="<?php echo site_url('site/viewEvents');?>"><i class="icon-font"></i><span class="hidden-tablet"> View events</span></a></li>
                      <li><a class="ajax-link" href="<?php echo site_url('site/viewDeals');?>"><i class="icon-font"></i><span class="hidden-tablet"> View deals</span></a></li>
                      <li><a class="ajax-link" href="<?php echo site_url('admin/places_/index');?>"><i class="icon-font"></i><span class="hidden-tablet"> Custom places</span></a></li>
                      <li><a class="ajax-link" href="<?php echo site_url('admin/places_/experiance');?>"><i class="icon-font"></i><span class="hidden-tablet"> Experience</span></a></li>
                      <li><a class="ajax-link" href="<?php echo site_url('admin/places_/News');?>"><i class="icon-font"></i><span class="hidden-tablet"> News</span></a></li>
                      
                      
                      <!-- <li><a href="<?php //echo site_url("Users/Timeline_operation/Post_message");?>">Timeline</a></li>  -->
                </ul>

				<?php /*?><!-- theme selector starts -->
				<div class="btn-group pull-right theme-container" >
					<a class="btn dropdown-toggle" data-toggle="dropdown" href="#">
						<i class="icon-tint"></i><span class="hidden-phone"> Change Theme / Skin</span>
						<span class="caret"></span>
					</a>
					<ul class="dropdown-menu" id="themes">
						<li><a data-value="classic" href="#"><i class="icon-blank"></i> Classic</a></li>
						<li><a data-value="cerulean" href="#"><i class="icon-blank"></i> Cerulean</a></li>
						<li><a data-value="cyborg" href="#"><i class="icon-blank"></i> Cyborg</a></li>
						<li><a data-value="redy" href="#"><i class="icon-blank"></i> Redy</a></li>
						<li><a data-value="journal" href="#"><i class="icon-blank"></i> Journal</a></li>
						<li><a data-value="simplex" href="#"><i class="icon-blank"></i> Simplex</a></li>
						<li><a data-value="slate" href="#"><i class="icon-blank"></i> Slate</a></li>
						<li><a data-value="spacelab" href="#"><i class="icon-blank"></i> Spacelab</a></li>
						<li><a data-value="united" href="#"><i class="icon-blank"></i> United</a></li>
					</ul>
				</div>
				<!-- theme selector ends --><?php */?>
				
				<!-- user dropdown starts -->
				<div class="btn-group pull-right" >
					<a class="btn dropdown-toggle" data-toggle="dropdown" href="#">
						<i class="icon-user"></i><span class="hidden-phone"> admin</span>
						<span class="caret"></span>
					</a>
					<ul class="dropdown-menu">
						<li><a href="#">Profile</a></li>
						<li class="divider"></li>
						<li><a href="<?php echo site_url('admin/login/logout');?>" >Logout</a></li>
					</ul>
				</div>
				<!-- user dropdown ends -->
				
				<?php /*?><div class="top-nav nav-collapse">
					<ul class="nav">
						<li><a href="#">Visit Site</a></li>
						<li>
							<form class="navbar-search pull-left">
								<input placeholder="Search" class="search-query span2" name="query" type="text">
							</form>
						</li>
					</ul>
				</div><?php */?><!--/.nav-collapse -->
			</div>
		</div>
	</div>
	<!-- topbar ends -->

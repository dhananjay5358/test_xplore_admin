<footer class="footer" id="footer">
	<p class="pull-left">&copy; <a href="" target="_blank">Travel App</a> 2013</p>
	<p class="pull-right">Powered by: <a href="">Freedom Lifted</a></p>
</footer>

  <script>

//  $(document).ready(function() 
 //{
 // var docHeight = $(window).height();
  //	console.log(docHeight);
  // var footerHeight = $('#footer').height();
  // var footerTop = $('#footer').position().top + footerHeight;
  // console.log(footerTop);
  // if (footerTop < docHeight) {


  // $('#footer').css('margin-top', ((docHeight-400) - footerTop) + 'px');
// }
 // });
 </script>




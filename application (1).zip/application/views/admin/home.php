<html>
	<head>
		<title>Dashboard</title>
    </head>
	
	<body>		
		<?php echo $admin_header; ?>
		
		<div class="container-fluid">
		  <div class="row-fluid">
		   
		   
		   
			<div id="content" class="span10">
			<!-- content starts -->
				<?php /*?><div>
					<ul class="breadcrumb">
						<li>
							<a href="#">Home</a> <span class="divider">/</span>
						</li>
						<li>
							<a href="#">Dashboard</a>
						</li>
					</ul>
				</div><?php */?>
				
				
				
			</div>	
			
			
		 </div>
		 
		 <?php include 'admin-footer.php'; ?>
	   </div>	 	
	
	</body>
</html>

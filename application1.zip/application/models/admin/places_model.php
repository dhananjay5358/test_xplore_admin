<?php
class places_model extends CI_Model
{

	public function __construct()
	{
		$this->load->database();
	}

	function get_custom_places($wheres = array(),$total = false, $limit = 10, $offset = 0,$all = false)
	{
		if(!empty($wheres))
		{
			foreach($wheres as $key => $val)
			{
				$this->db->where($key , $val);
			}
		}

		if(!$total && !$all)
		{
			$this->db->limit($limit,$offset); 
		}
		
		$query = $this->db->get('custom_places');
		
		if($query->num_rows() > 0)
		{
			if($total)
			{
				$data = $query->num_rows();
			}
			else
			{
				$data = $query->result_array();
			}
			return $data;
		}
		return false;
	}

	function remove_custom_place($id)
	{
		$this->db->where('experince_id', $id);
		$this->db->delete('experiance');
	}

	
	function get_places_info($wheres = array(),$total = false, $limit = 10, $offset = 0,$all = false)
	{
		
		if(!empty($wheres))
		{
			foreach($wheres as $key => $val)
			{
				$this->db->where($key , $val);
			}
		}
		if(!$total && !$all)
		{
			$this->db->limit($limit,$offset); 
		}

		$query = $this->db->get('Place_detail');
		
		if($query->num_rows() > 0)
		{
			if($total)
			{
				$data = $query->num_rows();
			}
			else
			{
				$data = $query->result_array();
			}

			return $data;
		}
		return false;
	}

	function get_places_info_for_exp()
	{
		$this->db->where('SrNumber !=' , '25');
		$this->db->or_where('Place_Type !=' , 'Deals');
		$this->db->or_where('Place_Type !=' , 'Events');
		$query = $this->db->get('Place_detail');
		$data = $query->result_array();
		return $data;
	}

	function get_user_info_for_exp()
	{
		$this->db->distinct();
		$this->db->select('FbUserId');
		$query = $this->db->get('Itineraries_store');
		$data = $query->result_array();
		return $data;
	}

	
	function remove_experiences($id)
	{
		$this->db->where('sr_no', $id);
		$this->db->delete('custom_places');
	}

	function edit_custom_place($id,$data)
	{
		$this->db->where('sr_no', $id);
		$this->db->update('custom_places', $data); 
	}

	function accept_custom_place($data)
	{
		$this->db->set($data);
	    $this->db->insert('Place_detail',$data);    
	    return $this->db->insert_id();    
	}

	function save_custom_place($data)
	{
		$this->db->set($data);
	    $this->db->insert('custom_places',$data);    
	    return $this->db->insert_id(); 
	}

	function save_custom_news($data)
	{
		$this->db->set($data);
	    $this->db->insert('custom_news',$data);    
	    return $this->db->insert_id(); 
	}

	function get_custom_news($wheres = array(),$total = false, $limit = 10, $offset = 0,$all = false)
	{
		if(!empty($wheres))
		{
			foreach($wheres as $key => $val)
			{
				$this->db->where($key , $val);
			}
		}

		if(!$total && !$all)
		{
			$this->db->limit($limit,$offset); 
		}
		
		$query = $this->db->get('custom_news');
		
		if($query->num_rows() > 0)
		{
			if($total)
			{
				$data = $query->num_rows();
			}
			else
			{
				$data = $query->result_array();
			}
			return $data;
		}
		return false;
	}

	function update_custom_news($data,$id)
	{
		$this->db->where('sr_no', $id);
		$this->db->update('custom_news', $data); 
	}

	function remove_custom_news($id)
	{
		$this->db->where('sr_no', $id);
		$this->db->delete('custom_news');
	}

	function get_news()
	{
		$query = $this->db->get('custom_news');
		
		if($query->num_rows() > 0)
		{
			$data = $query->result_array();
			return $data;
		}
		return false;
	}

	function add_experinces($data)
	{ 	
		$this->db->insert('experiance',$data); 
		return $this->db->insert_id();   
	}

	function getExperiences($wheres = array(),$total = false, $limit = 20, $offset = 0)
	{
		
		$this->db->select('*');
		$this->db->from('experiance');
		if(!empty($wheres))
		{
			foreach($wheres as $key => $val)
			{
				$this->db->where($key , $val);
			}
		}
		$this->db->order_by("experiance.experince_id", "asc");
		if(!$total)
			{
				$this->db->limit($limit,$offset);
			}
		$query = $this->db->get();
		if($query->num_rows() > 0)
		{
			if($total)
			{
				$data = $query->num_rows();
			}else{
			$data = $query->result_array();
			}
			return $data;
		}
		return false;
	}

	function get_places($wheres = array(),$total = false, $limit = 10, $offset = 0)
	{
		if(!empty($wheres))
		{
			foreach($wheres as $key => $val)
			{
				$this->db->where($key , $val);
			}
		}
		if(!$total)
			{
				$this->db->limit($limit,$offset);
			}
		$query = $this->db->get('experiance');
		if($query->num_rows() > 0)
		{
			if($total)
			{
				$data = $query->num_rows();
			}else{
			$data = $query->result_array();
			}
			return $data;
		}
		return false;
	}

	function get_place_info($wheres = array())
	{
		if(!empty($wheres))
		{
			foreach($wheres as $key => $val)
			{
				$this->db->where($key , $val);
			}
		}
		$this->db->order_by("Detail", "asc"); 
		//$this->db->limit($limit,$offset);
		$query = $this->db->get('Place_detail');
		if($query->num_rows() > 0)
		{			
			$data = $query->result_array();
			return $data;
		}
		return false;
	}

	function update_places($data)
	{
		$this->db->where('experince_id', $data['experince_id']);
		$this->db->update('experiance', $data); 
		return $this->db->insert_id();
	}
	

	function add_experinces_to_user($data)
	{
		$this->db->insert('Itineraries_store',$data); 
		return $this->db->insert_id();  
	}
	
             
}

?>
<footer class="footer">
	<p class="pull-left">&copy; <a href="" target="_blank">Travel App</a> 2013</p>
	<p class="pull-right">Powered by: <a href="">Freedom Lifted</a></p>
</footer>
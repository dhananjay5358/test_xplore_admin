<html>
	<head>
		<style>
			.jqimessage input{
				width: 87%;
			}

			#Excerpt_ {
				width:87%;
			}
		</style>
		<title>News</title>
		<script type="text/javascript">
			
			function prompt_delete_gallery(id)
			{
				var show_delete_media_box=[{
							title:"Delete Image Gallery",
							html: "<strong>are you really want to delete this news ?</strong>",
							buttons:{"Delete" : true , "Cancel" : false},
							submit: function(e,v,m,f){
								if(v==true)
								{									
									conformed_delete_gallery(id);									
								}
							
							}
						}];
				$.prompt(show_delete_media_box);
			}
			
			function conformed_delete_gallery(id)
			{
				$.ajax({
							url: '<?php echo site_url('admin/places_/add_or_remove_custom_news');?>',		
							type: 'POST',
							data: {
									'status' : 'remove' ,
									'id': id
								  },
							success: function(resp) {
								//alert(resp);
								window.location.reload();						
							}
						});
			
			}

			function prompt_accept_gallery(id)
			{
				var data = $(id).closest('tr');
				var link = "<?php echo site_url('admin/places_/edit_news'); ?>";
				var html = '<form method="POST" id="contact" name="13" action="'+link+'" class="form-horizontal" enctype="multipart/form-data">';
				html = html + "<br/><label>Title</label><input type='text' value='"+data.find('.Title').html()+"' name='Title_'/><br/><label>Excerpt</label><textarea name='Excerpt_'  id='Excerpt_' >'"+data.find('.Excerpt').html()+"'</textarea><br/><label>Image</label><input type='file' name='Image_'/><br/><img src='"+data.find('.Image').attr('src')+"'/><br/><label>Link</label><input type='text' value='"+data.find('.Link').html()+"' name='Link_'/></br><label>Date</label><input type='text' value='"+data.find('.Date').html()+"' name='date_' id='date_'/>";
				html = html + '<br/><br/><br/><div class="jqibuttons"><button name="jqi_0_buttonsubmit" id="jqi_0_buttonsubmit" value="true" class="jqidefaultbutton">submit</button><button name="jqi_0_buttonCancel" id="jqi_0_buttonCancel" value="false" class="jqidefaultbutton">Cancel</button></div></form>';

				var show_delete_media_box=[{
							title:"Accept place",
							html: html,
							buttons:{"accept" : true , "Cancel" : false},
							submit: function(e,v,m,f){
								if(v==true)
								{									
									accept_gallery(id);									
								}
							
							}
						}];
				$.prompt(show_delete_media_box);
			}

			function prompt_edit_gallery(id)
			{
				var data = $(id).closest('tr');
				// alert(data.find('.place_name').html());
				// data.find('.address').html();
				// data.find('.longitude').html();
				// data.find('.latitude').html();
				// data.find('.web').html();
				// data.find('.phone').html();
				// data.find('.Image').html();

				var link = "<?php echo site_url('admin/places_/edit_news'); ?>";
				var html = '<form method="POST" id="contact" name="13" action="'+link+'" class="form-horizontal" enctype="multipart/form-data">';
				html = html + "<br/><input type='hidden' name='id' value='"+$(id).attr('id')+"'><input type='hidden' name='id_image' value='"+data.find('.Image_1').attr('data')+"'><label>Title</label><input type='text' value='"+data.find('.Title').html()+"' name='Title_'/><br/><label>Excerpt</label><textarea name='Excerpt_'  id='Excerpt_' >"+data.find('.Excerpt').html()+"</textarea><br/><label>Image</label><input type='file' name='Image_'/><br/><img src='"+data.find('.Image_1').attr('src')+"' style='width:150px;height:150px;'/><br/><label>Link</label><input type='text' value='"+data.find('.Link').html()+"' name='Link_'/></br><label>Date</label><input type='text' value='"+data.find('.Date').html()+"' name='date_' id='date_'/>";
				html = html + '<br/><br/><br/><div class="jqibuttons"><button name="jqi_0_buttonsubmit" id="jqi_0_buttonsubmit" value="true" class="jqidefaultbutton">submit</button><button name="jqi_0_buttonCancel" id="jqi_0_buttonCancel" value="false" class="jqidefaultbutton">Cancel</button></div></form>';
				var show_delete_media_box=[{
							title:"Edit place",
							html: html,
							buttons:{},
							submit: function(e,v,m,f){
								if(v==true)
								{									
									// edit_gallery(id);									
								}
							
							}
						}];
				$.prompt(show_delete_media_box);
				$( "#date_" ).datepicker({ dateFormat: 'yy-mm-dd' });
			}

			function accept_gallery(id)
			{
				var place_name = $('#place_name_').val();
				var address = $('#address_').val();
				var longitude = $('#longitude_').val();
				var latitude = $('#latitude_').val();
				var web = $('#web_').val();
				var phone = $('#phone_').val();
				var Image = $('#Image_').val();
				var description = $('#description_').val();
				var category = $('#category_').val();
				
				$.ajax({
						url: '<?php echo site_url('admin/places_/accept_Place');?>',		
						type: 'POST',
						data: {
								'id' : $(id).attr('id'),
								'place_name' : place_name ,
								'address': address,
								'longitude': longitude,
								'latitude': latitude,
								'web': web,
								'phone': phone,
								'Image': Image,
								'description' : description,
								'category' : category
							  },
						success: function(resp) {
							//thiss.parentNode.previousSibling.innerHTML = interest;
							//window.location.reload();
							console.log(resp);	
						}
				});
			}

			function edit_gallery(id)
			{
				var place_name = $('#place_name').val();
				var address = $('#address').val();
				var longitude = $('#longitude').val();
				var latitude = $('#latitude').val();
				var web = $('#web').val();
				var phone = $('#phone').val();
				var Image = $('#Image').val();
				var description = $('#description').val();
				var category = $('#category').val();
				
				$.ajax({
						url: '<?php echo site_url('admin/places_/edit_Place');?>',		
						type: 'POST',
						data: {
								'id' : $(id).attr('id'),
								'place_name' : place_name ,
								'address': address,
								'longitude': longitude,
								'latitude': latitude,
								'web': web,
								'phone': phone,
								'Image': Image,
								'description' : description,
								'category' : category
							  },
						success: function(resp) {
							//thiss.parentNode.previousSibling.innerHTML = interest;
							window.location.reload();
							//console.log(resp);	
						}
				});
			}

			function edit_gallery(id)
			{
				var place_name = $('#place_name').val();
				var address = $('#address').val();
				var longitude = $('#longitude').val();
				var latitude = $('#latitude').val();
				var web = $('#web').val();
				var phone = $('#phone').val();
				var Image = $('#Image').val();
				var description = $('#description').val();
				var category = $('#category').val();
				
				$.ajax({
						url: '<?php echo site_url('admin/places_/edit_Place');?>',		
						type: 'POST',
						data: {
								'id' : $(id).attr('id'),
								'place_name' : place_name ,
								'address': address,
								'longitude': longitude,
								'latitude': latitude,
								'web': web,
								'phone': phone,
								'Image': Image,
								'description' : description,
								'category' : category
							  },
						success: function(resp) {
							//thiss.parentNode.previousSibling.innerHTML = interest;
							window.location.reload();
							//console.log(resp);	
						}
				});
			}

			function Create_News()
			{
				var link = "<?php echo site_url('admin/places_/save_news'); ?>";
				var html = '<form method="POST" id="contact" name="13" action="'+link+'" class="form-horizontal" enctype="multipart/form-data">';
				html = html + "<br/><label>Title</label><input type='text' value='' name='Title_'/><br/><label>Excerpt</label><textarea value='' name='Excerpt_'  id='Excerpt_' ></textarea><br/><label>Image</label><input type='file' name='Image_'/><br/><label>Link</label><input type='text' value='' name='Link_'/></br><label>Date</label><input type='text' value='' name='date_' id='date_'/>";
				html = html + '<br/><br/><br/><div class="jqibuttons"><button name="jqi_0_buttonsubmit" id="jqi_0_buttonsubmit" value="true" class="jqidefaultbutton">submit</button><button name="jqi_0_buttonCancel" id="jqi_0_buttonCancel" value="false" class="jqidefaultbutton">Cancel</button></div></form>';
				var show_delete_media_box=[{
							title:"Edit place",
							html: html,
							buttons:{},
							submit: function(e,v,m,f){
								if(v==true)
								{									
									//save_news();									
								}
							}
						}];
				$.prompt(show_delete_media_box);
				$( "#date_" ).datepicker({ dateFormat: 'yy-mm-dd' });
			}

			// $('#contact').submit(function(event)
			// {
			// 	// var Title_ = $("#Title_").val();
			// 	// var Excerpt_ = $("#Excerpt_").val();
			// 	// var Image_ = $("#Image_")[0].files[0];
			// 	// var Link_ = $("#Link_").val();
			// 	// var date_ = $("#date_").val();

				
			// 	var form = $('#contact').serialize();    
			// 	console.log(form);
			// 	return;           
   //      		var Form_Data = new FormData($(form)[1]);

			// 	var form_data = new FormData();                  // Creating object of FormData class
			// 	form_data.append("Title_", Title_);              // Appending parameter named file with properties of file_field to form_data
			// 	form_data.append("Excerpt_", Excerpt_);
			// 	form_data.append("Link_", Link_ );
			// 	form_data.append("date_", date_);
			// 	form_data.append("file", Image_);  
		
			// 	$.ajax({
			//             url: "<?php echo site_url('admin/places_/save_news');?>",
  	// 					contentType: false,
			//             processData: false,
			//             data: Form_Data,                         // Setting the data attribute of ajax with file_data
			//             type: 'POST',
			// 			success: function(resp) {
			// 				console.log(resp);
			// 				//window.location.reload();
			// 			}
			//    });
			// });
			
		</script>
	</head>
	<body>
		<?php echo $admin_header;?>
		<div class="container-fluid">
		  	<div class="row-fluid">
		   	<?php include 'left-sidebar.php'; ?> 
			<div id="content" class="span10">
				<div class="box span12">
					<div class="box-header well" data-original-title>
						<h2><i class="icon-user"></i> Custom News</h2>
						<div class="box-icon">
							<!--<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>-->
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<table class="table table-striped table-bordered bootstrap-datatable datatable">
							<thead>
								<tr>
									<th>Sr no</th>
									<th style="width:150px">Image</th>
									<th>Title</th>
									<th>Excerpt</th>
									
									<th>Link</th>
									<th>Date</th>
									<th><a class="btn btn-info" id="" onClick="Create_News()" ><i class="icon-plus icon-white"></i>Create</a></th>
								</tr>
							</thead>
							<tbody id='galleryList'>
							<?php 	
							if($experiances['0'] != "no-data") 
							{
								$i = (isset($index) ? $index : 0);
								foreach($experiances as $gallery)
								{ 
									$i++;
									?>
									<tr id="News_<?php echo $gallery['sr_no'];?>">
										<td><?php echo $i;?></td>
										<td class="Image" ><img class="Image_1" data="<?php echo $gallery['Image'];?>" src="https://s3.amazonaws.com/retail-safari/<?php echo $gallery['Image'];?>" style="Height: 120px; width: 150px;"/></td>
										<td class="Title" ><?php echo $gallery['Title'];?></td>
										<td class="Excerpt" ><?php echo $gallery['Excerpt'];?></td>
										
										<td class="Link" ><?php echo $gallery['Link'];?></td>
										<td class="Date" ><?php echo $gallery['Date'];?></td>
										<td ><a class="btn btn-info" id="<?php echo $gallery['sr_no'];?>" onClick="prompt_edit_gallery(this); return false;" ><i class="icon-edit icon-white"></i>Edit</a>	<a class="btn btn-danger"  href="#" onClick="prompt_delete_gallery(this.id); return false;" id="<?php echo $gallery['sr_no'];?>">	<i class="icon-trash icon-white"></i>Delete</a></td>								
									</tr>
								<?php
								}
							} 
							?>	
							</tbody>	
						</table>
					</div>
				</div>
				<ul id="pagination-digg"><?php if(isset($pages)) echo $pages;?></ul>
	   </div>
    </div>
	
	<?php include 'admin-footer.php'; ?>
	
   </div>		
	</body>
</html>

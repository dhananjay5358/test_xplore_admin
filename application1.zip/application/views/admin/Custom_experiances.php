<html>
	<head>
		<style>
			.jqimessage input{
				width: 87%;
			}
			._button {
			    padding: 6px;
			    display: inline;
			    border-radius: 2px;
			    font-family: "Arial";
			    border: 0;
			    margin: 0 6px;
			    background: #2F6073;
			    font-size: 15px;
			    line-height: 15px;
			    color: white;
			    width: auto;
			    height: auto;
			    box-sizing: content-box;
			}
		</style>
		<title>Custom Places List</title>
		<script type="text/javascript">
			var data_for_select='';
			function prompt_delete_gallery(id)
			{
				var show_delete_media_box=[{
							title:"Delete Custom places list",
							html: "<strong>are you really want to delete this Gallery ?</strong>",
							buttons:{"Delete" : true , "Cancel" : false},
							submit: function(e,v,m,f){
								if(v==true)
								{									
									conformed_delete_gallery(id);									
								}
							
							}
						}];
				$.prompt(show_delete_media_box);
			}
			
			function conformed_delete_gallery(id)
			{
				$.ajax({
							url: '<?php echo site_url('admin/places_/add_or_remove_custom_place');?>',		
							type: 'POST',
							data: {
									'status' : 'remove' ,
									'id': id
								  },
							success: function(resp) {
								//alert(resp);
								window.location.reload();						
							}
						});
			
			}

			function prompt_accept_gallery(id)
			{
				var data = $(id).closest('tr');

				var html = "<br/><label>Place name</label><input type='text' value='"+data.find('.place_name').html()+"' id='place_name_'/><br/><label>Address</label><input type='text' value='"+data.find('.address').html()+"' id='address_'/><br/><label>Description</label><input type='text' value='"+data.find('.description').html()+"' id='description_'/><br/><label>Category</label><input type='text' value='"+data.find('.category').html()+"' id='category_'/></br><label>Longitude</label><input type='text' value='"+data.find('.longitude').html()+"' id='longitude_'/><br/><label>Latitude</label><input type='text' value='"+data.find('.latitude').html()+"' id='latitude_'/><br/><label>Website</label><input type='text' value='"+data.find('.web').html()+"' id='web_'/><br/><label>Phone</label><input type='text' value='"+data.find('.phone').html()+"' id='phone_'/><br/><label>Image</label><input type='text' value='"+data.find('.Image').html()+"'  id='Image_'/>";
				var show_delete_media_box=[{
							title:"Accept place",
							html: html,
							buttons:{"accept" : true , "Cancel" : false},
							submit: function(e,v,m,f){
								if(v==true)
								{									
									accept_gallery(id);									
								}
							
							}
						}];
				$.prompt(show_delete_media_box);
			}

			function prompt_edit_gallery(thiss)
			{
				//var data = $(id).closest('tr');
				$.ajax({
							url: '<?php echo site_url('admin/places_/getEdit_places');?>',		
							type: 'POST',
							data: {
									'id': thiss.id
								  },
							success: function(resp) {


								var data = eval('('+resp+')');


								var placename = data['0'];
								var exp = data['1'];
								
								for(var i=0;i<exp.length;i++)
								{
									//console.log(exp[i].places);
									var exp_place_seperate = exp[i].places.split(",");
								}


								var place_sel_box = '<select id="place_sel_box"><option value="0">Please Select Places</option>';
								if(exp['0']!='no-data')
								{		

									for(var i=0;i<placename.length;i++)
									{

										var detail = placename[i].Detail;

										var det = JSON.parse(placename[i].Detail);
										var exp_place = (exp_place_seperate[0]).split(":");
										if(exp_place[0]==placename[i].PlaceIds)
										{
											place_sel_box = place_sel_box + '<option value="'+placename[i].PlaceIds+'" selected>'+det.name+'</option>';
										}else
										{

											place_sel_box = place_sel_box + '<option value="'+placename[i].PlaceIds+'">'+det.name+'</option>';
										}
									}																		
								}
								place_sel_box = place_sel_box + '</select>';

								 // console.log(exp[0].tour_description);
								 // return;
								
								var html = '<br/><form method="POST" enctype="multipart/form-data" class="form-horizontal"><input type="hidden" id="exper_id" value="'+exp[0].experince_id+'"></input><label>Tour name</label><input type="text" value="'+exp[0].tour_name+'" id="tour_name_info"/><br/><label>Tour description</label><input type="text" value="'+exp[0].tour_description+'" id="tour_desc_info"/><br/><label>Tags</label><input type="text" value="'+exp[0].tags+'" id="tagsinfo"/><br/><label>Public private group</label><input class="input-xlarge" type="radio" id="public_" name="ppgroup_info" value="1" '+((exp[0].public_private_group == 1 || exp[0].public_private_group == '1') ? 'checked' : '')+'>Public</input><input class="input-xlarge" type="radio" id="private_" name="ppgroup_info" value="2" '+((exp[0].public_private_group == 2 || exp[0].public_private_group == '2') ? 'checked' : '')+'>Private</input><input class="input-xlarge" type="radio" id="sharedinfo" name="ppgroup_info" value="3" '+((exp[0].public_private_group == 3 || exp[0].public_private_group == '3') ? 'checked' : '')+'>Shared</input></br><div class="control-group"><label class="control-label" for="place_select_box">Select places * : </label><div class="controls">'+place_sel_box+'</div></div></form><br/>';
								var edit_exp_box=[{
											title:"Edit place",
											html: html,
											buttons:{"Edit" : true , "Cancel" : false},
											submit: function(e,v,m,f){
												if(v==true)
												{										
													var tour_name_ = (document.getElementById('tour_name_info').value).replace(/^\s+|\s+$/g,'');
													var tour_description_ = document.getElementById('tour_desc_info').value;
													var tags_ = document.getElementById('tagsinfo').value;
													var group_ = $('input[name=ppgroup_info]:radio:checked').val();

													var places_ = (document.getElementById('places_info').value).replace(/^\s+|\s+$/g,'');
													if(tour_name_=='')
													{
														alert("Tour name cannot be empty.");
														document.getElementById('tour_name_info').focus();
														e.preventDefault();
													}else if(tour_description_=='')
													{
														alert("Tour description can not be empty.");
														document.getElementById('tour_desc_info').focus();
														e.preventDefault();
													}else if(tags_=="")
													{
														alert("Tags can not be empty.");
														document.getElementById('tagsinfo').focus();
														e.preventDefault();
													}else if(group_=='')
													{
														alert("Group cannot be empty.");
														document.getElementById('ppgroup_info').focus();
														e.preventDefault();
													}else if(places_=='')
													{
														alert("Places cannot be empty.");
														document.getElementById('places_info').focus();
														e.preventDefault();
													}else
													{
														edit_experience(tour_name_,tour_description_,tags_,group_,places_);										
													}			
												}	
												
						
											}
										}];
									$.prompt(edit_exp_box);
								}
						});
			}

			function accept_gallery(id)
			{
				var place_name = $('#place_name_').val();
				var address = $('#address_').val();
				var longitude = $('#longitude_').val();
				var latitude = $('#latitude_').val();
				var web = $('#web_').val();
				var phone = $('#phone_').val();
				var Image = $('#Image_').val();
				var description = $('#description_').val();
				var category = $('#category_').val();
				
				$.ajax({
						url: '<?php echo site_url('admin/places_/accept_Place');?>',		
						type: 'POST',
						data: {
								'id' : $(id).attr('id'),
								'place_name' : place_name ,
								'address': address,
								'longitude': longitude,
								'latitude': latitude,
								'web': web,
								'phone': phone,
								'Image': Image,
								'description' : description,
								'category' : category
							  },
						success: function(resp) {
							//thiss.parentNode.previousSibling.innerHTML = interest;
							//window.location.reload();
							console.log(resp);	
						}
				});
			}

			function edit_experience(tour_name_,tour_description_,tags_,group_,places_)
			{
				var experince_id = document.getElementById('exper_id').value;
				console.log(experince_id);
				console.log(tour_name_);
				//return;
				$.ajax({
						url: '<?php echo site_url('admin/places_/edit_Place');?>',		
						type: 'POST',
						data: {
								'experince_id' : experince_id,
								'tour_name' : tour_name_,
								'tour_desc': tour_description_,
								'tags': tags_,
								'ppgroup': group_,
								'places': places_
							  },
						success: function(resp) {
							//window.location.reload();
							console.log(resp);
						
						}
				});
			}

			// function edit_gallery(id)
			// {
			// 	var place_name = $('#place_name').val();
			// 	var address = $('#address').val();
			// 	var longitude = $('#longitude').val();
			// 	var latitude = $('#latitude').val();
			// 	var web = $('#web').val();
			// 	var phone = $('#phone').val();
			// 	var Image = $('#Image').val();
			// 	var description = $('#description').val();
			// 	var category = $('#category').val();
				
			// 	$.ajax({
			// 			url: '<?php //echo site_url('admin/places_/edit_Place');?>',		
			// 			type: 'POST',
			// 			data: {
			// 					'id' : $(id).attr('id'),
			// 					'place_name' : place_name ,
			// 					'address': address,
			// 					'longitude': longitude,
			// 					'latitude': latitude,
			// 					'web': web,
			// 					'phone': phone,
			// 					'Image': Image,
			// 					'description' : description,
			// 					'category' : category
			// 				  },
			// 			success: function(resp) {
			// 				//thiss.parentNode.previousSibling.innerHTML = interest;
			// 				window.location.reload();
			// 				//console.log(resp);	
			// 			}
			// 	});
			// }

			function Create_experiance()
			{
				$.ajax({
				url: '<?php echo site_url('admin/places_/get_placeslist');?>',		
				data: null,
				success: function(response) 
				{
						var placename = eval('('+response+')');
						var place_select_box = '<select id="place_select_box" name ="place_select_box[]"><option value="" selected>Please Select places</option>';
						console.log(placename);
						if(placename.places['0']!='no-data')
						{									
							for(var i=0;i<placename.places.length;i++)
							{
								var Detail = placename.places[i].Detail;
								var det = JSON.parse(placename.places[i].Detail);
								place_select_box = place_select_box + '<option value="'+placename.places[i].PlaceIds+'">'+det.name+'</option>';
							}																		
						}

						place_select_box = place_select_box + '</select>';
						data_for_select = place_select_box;
						
						var user = '<div><span>User List &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span><select id="user_select_box" name ="user_select_box[]"><option value="" selected>Please Select user</option>';
						if(placename.user['0']!='no-data')
						{									
							for(var i=0;i<placename.user.length;i++)
							{
								user = user + '<option value="'+placename.user[i].FbUserId+'">'+placename.user[i].FbUserId+'</option>';
							}																		
						}
						user = user + '</select></span></div>';

						var link = "<?php echo site_url('admin/places_/add_places'); ?>";
						var html = "<br/><form method='POST' action='"+link+"' enctype='multipart/form-data' class='form-horizontal'><label>Tour name</label><input type='text' value='' id='tour_name' name='tour_name'/><br/><label>Tour Description</label><input type='text' value='' id='tour_description' name='tour_description'/><br/><label>Tags</label><input type='text' value='' id='tags_detail' name='tags_detail'/><br/><label>Public_private_group</label><input class='input-xlarge' type='radio' id='public_' name='group_detail' value='Public' checked>Public</input><input class='input-xlarge' type='radio' id='private_' name='group_detail' value='Private'>Private</input><input class='input-xlarge' type='radio' id='shared_' name='group_detail' value='Shared' checked>Shared</input></br><div id='data_place'><div><span>Select Places * :</span><span>'"+place_select_box+"'</span><span class='_button' id='add' onclick='add_place_dropdown();'>+</span></div><br/><div><span>Description&nbsp;&nbsp;&nbsp; * :</span><span><textarea name='description[]'></textarea></span></div></div><br/><div>'"+user+"'</div>";
						html = html + '<br/><br/><br/><div class="jqibuttons"><button name="jqi_0_buttonsubmit" id="jqi_0_buttonsubmit" value="true" class="jqidefaultbutton">submit</button><button name="jqi_0_buttonCancel" id="jqi_0_buttonCancel" value="false" class="jqidefaultbutton">Cancel</button></div></form>';	
							var show_create_experience_box=[{
							title:"Create places",
							html: html,
							buttons:{},
							submit: function(e,v,m,f){
								if(v==true)
								{									
									// var tour_name = (document.getElementById('tour_name').value).replace(/^\s+|\s+$/g,'');
									// var tour_description = document.getElementById('tour_description').value;
									// var tags = document.getElementById('tags_detail').value;
									// // var group = (document.getElementById('group_detail').value).replace(/^\s+|\s+$/g,'');
									// var group = $('input[name=group_detail]:radio:checked').val();
									// // var places = (document.getElementById('places_detail').value).replace(/^\s+|\s+$/g,'');

									// var places = document.getElementById('place_select_box').value ? (document.getElementById('place_select_box').value) : '0';

									// if(tour_name=='')
									// {
									// 	alert("Tour name cannot be empty.");
									// 	document.getElementById('tour_name').focus();
									// 	e.preventDefault();
									// }else if(tour_description=='')
									// {
									// 	alert("Tour description can not be empty.");
									// 	document.getElementById('tour_description').focus();
									// 	e.preventDefault();
									// }else if(tags=="")
									// {
									// 	alert("Tags can not be empty.");
									// 	document.getElementById('tags_detail').focus();
									// 	e.preventDefault();
									// }else if(places=='')
									// {
									// 	alert("Places cannot be empty.");
									// 	document.getElementById('places_detail').focus();
									// 	e.preventDefault();
									// }else
									// {
									// 	add_places(tour_name,tour_description,tags,group,places);										
									// }			
								}
							
							}
						}];
						$.prompt(show_create_experience_box);
				}
				});	
			}

			function add_place_dropdown()
			{
				$('#data_place').append("<br/><div><span>Select Places * :</span><span>'"+data_for_select+"'</span><br/><br/><div><span>Description&nbsp;&nbsp;&nbsp; * :</span><span><textarea name='description[]'></textarea></span></div></div>");
			}
			
			function add_places(tour_name,tour_description,tags,group,places)
			{
				
				$.ajaxFileUpload({
					url:"<?php echo site_url("admin/places_/add_places"); ?>",
					secureuri:false,
					fileElementId:'userfile',
					dataType: 'JSON',
					type: 'POST',
					data:{
							'tour_name' : tour_name ,
							'tour_description' : tour_description ,
							'tags' : tags ,
							'group' : group ,	
							'places' : places	
						 },
					success: function (resp)
							{
								// if(data=='OK')
								// {
								// 	window.location.reload();
								// }
								// else
								// {
								// 	alert("Some Error...");	
								// }
							}

					});
			
			}			
		</script>
	</head>
	<body>
		<?php echo $admin_header;?>
		<div class="container-fluid">
		  <div class="row-fluid">
		   
		   <?php include 'left-sidebar.php'; ?> 
		   
			<div id="content" class="span10">
				<div class="box span12">
					<div class="box-header well" data-original-title>
						<h2><i class="icon-user"></i> Custom Places List</h2>
						<div class="box-icon">
							<!--<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>-->
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						
						<table class="table table-striped table-bordered bootstrap-datatable datatable">
							<thead>
								<tr>
									<th>Index</th>
									<th>Tour_name</th>
									<th>tour_description</th>
									<th>Tags</th>
									<th>Public_private_group</th>
									<th style="display:none;">Places</th>
									<th><a class="btn btn-info" id="" onClick="javascript:Create_experiance(); return false;"><i class="icon-plus icon-white"></i>Create</a></th>
								</tr>
							</thead>
							<tbody id='galleryList'>
								<?php 	
								if($galleries['0'] != "no-data") 
								{
									$i = (isset($index) ? $index : 0);
									
									foreach($galleries as $gallery)
									{ 
										$i++;
										?>
										<tr id="gallery<?php echo $gallery['experince_id'];?>">
											<td><?php echo $i;?></td>
											<td class="Tour_name" ><?php echo $gallery['tour_name'];?></td>
											<td class="description" ><?php echo $gallery['tour_description'];?></td>
											<td class="tags" ><?php echo $gallery['tags'];?></td>
											<td class="p_p_group" ><?php echo $gallery['public_private_group'];?></td>
											<td class="places" style="display:none;" ><?php echo $gallery['places'];?></td>
											<td ><a class="btn btn-info"  onClick="javascript:prompt_edit_gallery(this); return false;" id="<?php echo $gallery['experince_id'];?>"><i class="icon-edit icon-white"></i>Edit</a>
												 <a class="btn btn-danger"   onClick="prompt_delete_gallery(this.id); return false;" href="#" id="<?php echo $gallery['experince_id'];?>"><i class="icon-trash icon-white"></i>Delete</a>   
												 <a class="btn btn-info"  href="#" onClick="prompt_accept_gallery(this); return false;" id="<?php echo $gallery['experince_id'];?>">	<i class="icon-heart icon-white"></i>Accept</a></td>								

										</tr>
									<?php
									}
								} 
								?>
							</tbody>	
						</table>
						</div>
				  	</div>
				
		<ul id="pagination-digg"><?php if(isset($pages)) echo $pages;?></ul>	
	   </div>
    </div>
	
	<?php include 'admin-footer.php'; ?>
	
   </div>		
   </body>
</html>

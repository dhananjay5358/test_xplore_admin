<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class places_ extends CI_Controller {
	var $awsAccessKey = "AKIAJ2RVZ5W24XMUFG5A"; 
	var $awsSecretKey = "7GiP5Tidb/Qff0cLn41VnlHgKcJQ4kdUTFOIm4wz";
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();
		$this->load->model('admin/places_model');
		$this->load->model('site_model');
		$this->load->library('pagination');	
		$this->load->library('session');
		require_once(APPPATH.'libraries/S3.php');
	}

	public function index()
	{
		// if($this->session->userdata('identity'))
		// {
			$limit = 10;
			$offset = 0;
			if($total = $this->places_model->get_custom_places(array(),true))
			{
				$config['base_url'] = site_url('admin/Places/index/');
				$config['total_rows'] = $total;
				$config['per_page'] = $limit = 10;
				$config['uri_segment'] = 4;
				$config['num_links'] = 2;	
				
				$config['first_tag_open'] = '<li>';
				$config['first_tag_close'] = '</li>';
				$config['last_tag_open'] = '<li>';
				$config['last_tag_close'] = '</li>';
				$config['next_tag_open'] = '<li class="next">';
				$config['next_tag_close'] = '</li>';
				$config['prev_tag_open'] = '<li class="previous">';
				$config['prev_tag_close'] = '</li>';
				$config['cur_tag_open'] = '<li class="active">';
				$config['cur_tag_close'] = '</li>';
				$config['num_tag_open'] = '<li>';
				$config['num_tag_close'] = '</li>';
				// Initialize
				$this->pagination->initialize($config);
				$pages = $this->pagination->create_links();	
				$offset = $this->uri->segment(4) ? $this->uri->segment(4) : 0;
				$data['pages'] = $pages;
				$data['index'] = $offset;	
			}
				
			if(!($place_list = $this->places_model->get_custom_places(array(),false,$limit,$offset)))
			{
				$place_list['0'] = "no-data";	
			}
			$data['admin_header']=$this->load->view('admin/admin_header','',true);
			$data['galleries']= $place_list;
			$this->load->view('admin/Places_list',$data);
		// }
		// else
		// {
		// 	header('Location:'.site_url('admin/login/index') );
		// }
	}
	
	public function add_or_remove_custom_place()
	{
		if($_POST['status'] === 'remove')
		{
			$ids = $_POST['id'];
			$this->places_model->remove_custom_place($ids);		
		}
		exit;
	}

	public function getEdit_places()
	{
		$ids = explode('_',$_POST['id']);
		$expeience = $this->places_model->get_places(array('experince_id' => $ids['0']));
		
		if(!($placename = $this->places_model->get_places_info_for_exp()))
		{
			$arr['places']['0'] = "no-data";	
		}
		$result['0'] = 	$placename;
		$result['1'] = 	$expeience;
		echo json_encode($result);
			exit;	
	}

	public function infoSelectBoxes()
	{
		if(!($place_ = $this->places_model->get_place_info()))
				{
					$place_['0'] = "no-data";	
				}
			
		$result['0'] = 	$place_;
		return $result;
	}

	public function edit_Place()
	{
				$data=array();
            	$data['experince_id'] = $_POST['experince_id'];
				$data['tour_name'] = $_POST['tour_name'];
				$data['tour_description'] = $_POST['tour_desc'];
				$data['tags'] = $_POST['tags'];
				$data['public_private_group'] = $_POST['ppgroup'];
				$data['places'] = $_POST['places'];

				$id=$this->places_model->update_places($data);
            	echo $id;
			
	}

	public function accept_Place()
	{
		if($_POST['id'] != '')
		{
			$id = $_POST['id'];
			$Image = $_POST['Image'];

			$LatLng='{ "H":'.$_POST['latitude'].', "L":'.$_POST['longitude'].'}';

			$e = array();
			$e['name'] = $_POST['place_name'];
		    $e['address']  = $_POST['address'];
		    $e['price'] = "";
		    $e['date'] = "";
		    $e['startTime']  = "";
		    $e['endTime'] = "";
		    $e['about'] = base64_encode($_POST['description']);
		    $e['Reviews']  = "";
		    $e['type'] = $_POST['category'];
		    $e['Info_1'] = "";
		    $e['Info_2'] = "";
		    $e['Info_3'] =  "";
		    $e['Phone'] = $_POST['phone'];
		    $e['Website'] = $_POST['web'];
		    $e['Path'] = '';
		    $e['profileimage'] = $Image;

		    $placeId = random_string('alnum',20);
	 		$venueId = $placeId;

  			$detail = json_encode($e);
      		if(($sitelist = $this->site_model->addEventsPlaces($e['type'],$detail,$LatLng,$LatLng,$placeId,$venueId,"false")))
	  		{
				$this->places_model->remove_custom_place($id);	
	  		}	
	  		echo $venueId;	
		}
	}

	public function experiance()
	{
			
			$limit = 10;
			$offset = 0;
			if($total = $this->places_model->get_custom_places(array(),true))
			{
				$config['base_url'] = site_url('admin/Places/index/');
				$config['total_rows'] = $total;
				$config['per_page'] = $limit = 10;
				$config['uri_segment'] = 4;
				$config['num_links'] = 2;	
				
				$config['first_tag_open'] = '<li>';
				$config['first_tag_close'] = '</li>';
				$config['last_tag_open'] = '<li>';
				$config['last_tag_close'] = '</li>';
				$config['next_tag_open'] = '<li class="next">';
				$config['next_tag_close'] = '</li>';
				$config['prev_tag_open'] = '<li class="previous">';
				$config['prev_tag_close'] = '</li>';
				$config['cur_tag_open'] = '<li class="active">';
				$config['cur_tag_close'] = '</li>';
				$config['num_tag_open'] = '<li>';
				$config['num_tag_close'] = '</li>';
				// Initialize
				$this->pagination->initialize($config);
				$pages = $this->pagination->create_links();	
				$offset = $this->uri->segment(4) ? $this->uri->segment(4) : 0;
				$data['pages'] = $pages;
				$data['index'] = $offset;	
			}
			
			// if(!($media = $this->places_model->getExperiences(array(),false,$limit,$offset)))
			// {
			// 	$media['0'] = "no-data";	
			// }
			// $data['media'] = $media;
			
		
			if(!($place_list = $this->places_model->getExperiences(array(),false,$limit,$offset)))
			{
				$place_list['0'] = "no-data";	
			}
			$data['admin_header']=$this->load->view('admin/admin_header','',true);
			$data['galleries']= $place_list;

			$this->load->view('admin/Custom_experiances',$data);
	}

	public function News()
	{
		$limit = 10;
		$offset = 0;
		if($total = $this->places_model->get_custom_news(array(),true))
		{
			$config['base_url'] = site_url('admin/Places/index/');
			$config['total_rows'] = $total;
			$config['per_page'] = $limit = 10;
			$config['uri_segment'] = 4;
			$config['num_links'] = 2;	
			
			$config['first_tag_open'] = '<li>';
			$config['first_tag_close'] = '</li>';
			$config['last_tag_open'] = '<li>';
			$config['last_tag_close'] = '</li>';
			$config['next_tag_open'] = '<li class="next">';
			$config['next_tag_close'] = '</li>';
			$config['prev_tag_open'] = '<li class="previous">';
			$config['prev_tag_close'] = '</li>';
			$config['cur_tag_open'] = '<li class="active">';
			$config['cur_tag_close'] = '</li>';
			$config['num_tag_open'] = '<li>';
			$config['num_tag_close'] = '</li>';
			
			$this->pagination->initialize($config);
			$pages = $this->pagination->create_links();	
			$offset = $this->uri->segment(4) ? $this->uri->segment(4) : 0;
			$data['pages'] = $pages;
			$data['index'] = $offset;	
		}
			
		if(!($news_list = $this->places_model->get_custom_news(array(),false,$limit,$offset)))
		{
			$news_list['0'] = "no-data";	
		}

		$data['experiances']= $news_list;
		$data['admin_header']=$this->load->view('admin/admin_header','',true);
		$this->load->view('admin/Cust_News',$data);
	}

	public function save_news()
	{
		$Title_  	= 	$_POST['Title_'];
		$Excerpt_  	= 	$_POST['Excerpt_'];
		$Link_  	= 	$_POST['Link_'];
		$date_  	= 	$_POST['date_'];

		if(isset($_FILES['Image_']['name']) && (!empty($_FILES['Image_']['name'])))
		{
			$size = $_FILES['Image_']['size'];

	        if ($size < 1000000)
	        {
				$s3 = new S3($this->awsAccessKey, $this->awsSecretKey);

				$fileName = $_FILES['Image_']['name'];
		        $fileTempName = $_FILES['Image_']['tmp_name'];             
		        $newfilename = round(microtime(true)) . '.jpeg';

		        if($s3->putObjectFile($fileTempName, "retail-safari", $newfilename, S3::ACL_PUBLIC_READ))
		        {

	        		$Image = $newfilename;
	        		
	        		$data = array();
	        		$data['Title'] = $Title_;
	        		$data['Excerpt'] = $Excerpt_;
	        		$data['Link'] = $Link_; 
	        		$data['Date'] = $date_;
	        		$data['Image'] = $Image;

	        		$save_News = $this->places_model->save_custom_news($data);

	        		echo $save_News;
	        	}
	        	else
	        	{
	        		echo 'error';
	        	}
	        }
	        else
	        {
	        	echo "size_issue";
	        }
		}
		else
		{
			echo "empty";
		}
		
		//redirect('/admin/places_/News');
	}

	public function edit_news()
	{
		if($_POST['id'] != '')
		{
			$id 		= 	$_POST['id'];
			$Title_  	= 	$_POST['Title_'];
			$Excerpt_  	= 	$_POST['Excerpt_'];
			$Link_  	= 	$_POST['Link_'];
			$date_  	= 	$_POST['date_'];
			$Image 		= 	$_POST['id_image'];	

			if(isset($_FILES['Image_']['name']) && (!empty($_FILES['Image_']['name'])))
			{
				$size = $_FILES['Image_']['size'];

		        if ($size < 1000000)
		        {
					$s3 = new S3($this->awsAccessKey, $this->awsSecretKey);

					$fileName = $_FILES['Image_']['name'];
			        $fileTempName = $_FILES['Image_']['tmp_name'];             
			        $newfilename = round(microtime(true)) . '.jpeg';

			        if($s3->putObjectFile($fileTempName, "retail-safari", $newfilename, S3::ACL_PUBLIC_READ))
		        	{
		        		$Image = $newfilename;
		        		
		        		$data = array();
		        		$data['Title'] = $Title_;
		        		$data['Excerpt'] = $Excerpt_;
		        		$data['Link'] = $Link_; 
		        		$data['Date'] = $date_;
		        		$data['Image'] = $Image;

		        		$save_News = $this->places_model->update_custom_news($data,$id);

		        		echo $save_News;
		        	}
		        	else
		        	{
		        		echo 'error';
		        	}
		        }
		        else
		        {
		        	echo 'size issue';
		        }
			}
			else
			{
				$data = array();
        		$data['Title'] = $Title_;
        		$data['Excerpt'] = $Excerpt_;
        		$data['Link'] = $Link_; 
        		$data['Date'] = $date_;
        		$data['Image'] = $Image;

        		$save_News = $this->places_model->update_custom_news($data,$id);

        		echo $save_News;
			}	
		}
		echo $_POST['id'];
		redirect('/admin/places_/News');
	}

	public function add_or_remove_custom_news()
	{
		if($_POST['status'] === 'remove')
		{
			$ids = $_POST['id'];
			$this->places_model->remove_custom_news($ids);		
		}
		exit;
	}

	function get_news()
	{
		$data = $this->places_model->get_news();
		echo $_GET['callback'] .'('. json_encode($data) . ')';
		exit;	
	}

	public function add_places()
	{
		if(!isset($_POST))
		{
			redirect('/admin/places_/experiance');
			exit();
		}
		else if($_POST['tour_description'] == '')
		{
			redirect('/admin/places_/experiance');
			exit();
		}

		$description = $_POST['description'];
		$user_select_box = $_POST['user_select_box'];
		$place_select_box = $_POST['place_select_box'];
		$tour_name = $_POST['tour_name'];
		$tour_description = $_POST['tour_description'];
		$tags_detail = $_POST['tags_detail'];
		$group_detail = $_POST['group_detail'];

		$places_list_data=array();
		for ($i=0;$i<count($place_select_box);$i++) 
		{
			array_push($places_list_data,$place_select_box[$i].':'.base64_encode($description[$i]) );
		}

		$p_list = implode(",",$places_list_data);

		$data_res = $this->places_model->add_experinces(array(
												'tour_name'=>$tour_name,
												'tour_description'=>$tour_description,
												'tags'=>$tags_detail,
												'public_private_group'=>$group_detail,
												'places'=>$p_list)
											     );
		$place_detail_array=array();
		$place_detail_array['Places_List_all'] = $p_list;
		$place_detail_array['Description'] = $tour_name;

		foreach ($user_select_box as $key) 
		{
			if($key == '')
			{
				continue;
			}
			$this->places_model->add_experinces_to_user(array(
												'FbUserId'=>$key,
												'TourName'=>$tour_description,
												'Detail'=>json_encode($place_detail_array),
												'Profile'=>$group_detail,
												'Shared_id' =>$data_res)
											     );

		}
		// json_encode($jsondata, true);
		
		redirect('/admin/places_/experiance');
		exit();
	}

	public function get_placeslist()
	{

		if(!($arr['places'] = $this->places_model->get_places_info_for_exp()))   //not worry about 10,0 as last field i.e. all field are set to true.
		{
			$arr['places']['0'] = "no-data";	
		}

		if(!($arr['user'] = $this->places_model->get_user_info_for_exp()))   //not worry about 10,0 as last field i.e. all field are set to true.
		{
			$arr['user']['0'] = "no-data";	
		}

		echo json_encode($arr);
		exit;	
	}


}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
<?php
$start = microtime(true);
use TVW\Yelp;

require '../vendor/autoload.php';

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test-explore";

$conn = new mysqli($servername, $username, $password, $dbname);

$apiToken = 'A7F4RNSZ2wTYSwJ3xmpa8RYzTmw015wl_aPEa5cz3hYGoSvA5bLuP6ruxLpkyDLZS2Y27jNo0nJAz2vulnS-DLaXaSuoY54lnY76Dz-HrqzgVTD_QQZ6YHiyUeV1WXYx';

$yelpFusion = new Yelp($apiToken);
$in_str = '';
$update_str='';
$query = "SELECT SrNumber,Venueid, Detail FROM Place_detail";
$result = $conn->query($query);
$sql = "UPDATE Place_detail SET ";
        echo "<pre>";
        if ($result->num_rows > 0) 
        {
            while($row = $result->fetch_assoc()) {
                $detail=json_decode($row['Detail'],true);
                print_r($row['SrNumber']);  
                if(!empty($detail['businessId']))
                {
                    $businessesInfo = $yelpFusion->getDetails("details", $detail['businessId']);
                }
                if(isset($businessesInfo->hours[0])){
                $open_hrs=$businessesInfo->hours[0]->open;
                }
                if(isset($businessesInfo->is_closed))
                {
                $isClosed=var_dump($businessesInfo->is_closed);
                $is_Close_=$isClosed ? 'true' : 'false';
                }
                $hoursDay = '';
                foreach ($open_hrs as $value) {
                            if($value->day==0){
                              $day="Monday";
                            }else if($value->day==1){
                              $day="Tuesday";
                            }else if($value->day==2){
                              $day="Wednesday";
                            }else if($value->day==3){
                              $day="Thursday";
                            }else if($value->day==4){
                              $day="Friday";
                            }else if($value->day==5){
                              $day="Saturday";
                            }else{
                              $day="Sunday";
                            }
                            if(!empty($hoursDay))
                            {
                                $hoursDay = $hoursDay.",".$day.'_'.$value->start.'_'.$value->end;    
                            }
                            else
                            {
                                $hoursDay = $day.'_'.$value->start.'_'.$value->end;       
                            }

                            $detail_ = array();
                            $detail_['name'] = str_replace("'", '"', $detail['name']);
                            $detail_['address']  = str_replace("'", '"', $detail['address']);
                            $detail_['price'] = str_replace("'", '"', $detail['price']);
                            $detail_['date'] = str_replace("'", '"', $detail['date']);
                            $detail_['startTime']  =str_replace("'", '"', $detail['startTime']);
                            $detail_['endTime'] =str_replace("'", '"', $detail['endTime']);
                            $detail_['about'] = str_replace("'", '"', $detail['about']);
                            $detail_['Reviews']  = str_replace("'", '"', $detail['Reviews']);
                            $detail_['type'] = str_replace("'", '"', $detail['type']);
                            $detail_['businessId'] = str_replace("'", '"', $detail['businessId']);
                            $detail_['rating'] = str_replace("'", '"', $detail['rating']);
                            $detail_['Phone'] = str_replace("'", '"', $detail['Phone']);
                            $detail_['Like'] = str_replace("'", '"', $detail['Like']);
                            $detail_['Website']  = str_replace("'", '"', $detail['Website']);
                            $detail_['Path'] =isset($detail['Path']) ? str_replace("'", '"', $detail['Path']) : "";
                            $detail_['profileimage'] = isset($detail['profileimage']) ? str_replace("'", '"', $detail['profileimage']) : "";
                            $detail_['isClosed'] =  $is_Close_;
                            $detail_['hours'] = $hoursDay;
                            $detail_new = json_encode($detail_);

                            
                            $update_str .= "WHEN '".$row['SrNumber']."' THEN '".$detail_new."' ";
                            
                            if(empty($in_str))
                                $in_str .= "'".$row['SrNumber']."'";
                            else
                                $in_str .= ", '".$row['SrNumber']."'";
                            
                        
                }

            }
        }
        else
        {
               echo "0 results";
        }

$sql .= "Detail = CASE SrNumber ";
$sql .= $update_str;
$sql .= "END";
$sql .= " WHERE SrNumber IN (".$in_str.");";
echo "<pre>";

print_r($sql);
exit();
//$qry_result = mysqli_query($conn, $sql);

$end = microtime(true) - $start;

echo "<pre>";
print_r($end);

$conn->close();

?>